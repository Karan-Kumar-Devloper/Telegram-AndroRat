package com.KaranKumar.contact;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.IOException;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 123;
    private EditText edtText;
    private Button btnExport;
    private Button btnImport;
    private static String finalPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Developer")
            .setMessage("This app is created by karan kumar for You \n I Love You Dear User \n\n By @CyberZoneAcademy  ")
            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dia, int which) {

                }
            })
            .setNegativeButton("contact",new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dia, int which) {
                    
                    // Replace "https://example.com" with the URL you want to open
                    String url = "https://t.me/@CyberZoneAcademy";

                    // Create an Intent with ACTION_VIEW and the URI of the website
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                    // Set the package to Chrome to ensure it opens in Chrome
                    intent.setPackage("com.android.chrome");

                    // Check if there's a Chrome browser installed
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                    } else {
                        // If Chrome is not installed, open the URL in the default browser
                        intent.setPackage(null);
                        startActivity(intent);
                    }
                

                }
            })
            .create();
        dialog.show();

        edtText = findViewById(R.id.myEdtTxt);
        btnExport = findViewById(R.id.exportContact);
        btnImport = findViewById(R.id.importContact);

        finalPath = edtText.getText().toString();

        btnExport.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    checkPermissionAndExport();
                }
            });

        btnImport.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    checkPermissionAndImport();
                }
            });
    }

    private void checkPermissionAndExport() {
        if (checkPermissions()) {
            exportContacts();
        } else {
            requestPermissions();
        }
    }

    private void checkPermissionAndImport() {
        if (checkPermissions()) {
            importContacts();
        } else {
            requestPermissions();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                                              Manifest.permission.READ_CONTACTS,
                                              Manifest.permission.WRITE_CONTACTS,
                                              Manifest.permission.READ_EXTERNAL_STORAGE,
                                              Manifest.permission.WRITE_EXTERNAL_STORAGE
                                          }, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, perform the export or import
                if (btnExport.isPressed()) {
                    exportContacts();
                } else if (btnImport.isPressed()) {
                    importContacts();
                }
            } else {
                Toast.makeText(this, "Permission denied. Cannot perform the operation.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void exportContacts() {
        finalPath = edtText.getText().toString();
        if (finalPath.equals("")) {
            Toast.makeText(getApplication(), "Please enter the JSON file full path.", Toast.LENGTH_SHORT).show();
        } else {
            Log.i("FilePath", finalPath);
            if (!fileExists(finalPath)) {
                createFile(finalPath);
            }
            contactManager.exportContacts(MainActivity.this, finalPath);
        }
    }

    private void importContacts() {
        finalPath = edtText.getText().toString();
        if (finalPath.equals("")) {
            Toast.makeText(getApplication(), "Please enter the JSON file full path.", Toast.LENGTH_SHORT).show();
        } else {
            Log.i("FilePath", finalPath);
            if (!fileExists(finalPath)) {
                Toast.makeText(getApplication(), "File does not exist. Please provide a valid file path.", Toast.LENGTH_SHORT).show();
            } else {
                // Call the method for importing contacts
                contactManager.importContactsFromJson(MainActivity.this, finalPath);
            }
        }
    }

    private boolean fileExists(String filePath) {
        File file = new File(filePath);
        return file.exists();
    }

    private void createFile(String filePath) {
        
            File file = new File(filePath);
            try {
                if (file.createNewFile()) {
                    Log.i("FileCreation", "File created at: " + filePath);
                } else {
                    Log.i("FileCreation", "File already exists at: " + filePath);
                }
            } catch (IOException e) {}
        
    }
}
