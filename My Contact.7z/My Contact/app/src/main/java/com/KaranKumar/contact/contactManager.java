package com.KaranKumar.contact;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.Environment;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class contactManager {

    // Export contacts to a specified JSON file
    public static void exportContacts(Context context, String jsonFilePath) {
        JSONArray contactsArray = new JSONArray();
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        int index = 0; // Add an index variable

        if (cursor != null) {
            try {
                if (cursor.getCount() > 0) {
                    while (cursor.moveToNext()) {
                        String contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                        String contactNumber = getContactNumber(contentResolver, cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID)));

                        try {
                            JSONObject contactObject = new JSONObject();
                            contactObject.put("index", index); // Include the index
                            contactObject.put("name", contactName != null ? contactName : "");
                            contactObject.put("number", contactNumber != null ? contactNumber : "");
                            contactsArray.put(contactObject);

                            index++; // Increment the index for each contact
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } finally {
                cursor.close();
            }
        }

        saveContactsToFile(jsonFilePath, contactsArray);
    }

    // Import contacts from a specified JSON file
    public static void importContactsFromJson(Context context, String jsonFilePath) {
        try {
            String jsonString = Utils.readJsonFile(jsonFilePath);
            JSONArray contactsArray = new JSONArray(jsonString);

            for (int i = 0; i < contactsArray.length(); i++) {
                JSONObject contactObject = contactsArray.getJSONObject(i);

                String contactName = contactObject.optString("name", "");
                String contactNumber = contactObject.optString("number", "");

                saveContactToPhone(context, contactName, contactNumber);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // Import contacts by specifying either a name or a number
    public static void importContactByNameOrNumber(Context context, String name, String number) {
        if (!name.isEmpty() || !number.isEmpty()) {
            saveContactToPhone(context, name, number);
        }
    }

    private static String getContactNumber(ContentResolver contentResolver, String contactId) {
        String number = null;
        Cursor phones = null;

        try {
            phones = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                           null,
                                           ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId,
                                           null,
                                           null);

            if (phones != null && phones.moveToFirst()) {
                number = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            }
        } finally {
            if (phones != null) {
                phones.close();
            }
        }

        return number;
    }

    private static void saveContactsToFile(String jsonFilePath, JSONArray contactsArray) {
        try {
            File file = new File(jsonFilePath);
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(contactsArray.toString(2));
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    private static void saveContactToPhone(Context context, String name, String number) {
        ArrayList<ContentProviderOperation> ops = new ArrayList<>();

        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build());

        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                .build());

        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                .build());

        try {
            context.getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
