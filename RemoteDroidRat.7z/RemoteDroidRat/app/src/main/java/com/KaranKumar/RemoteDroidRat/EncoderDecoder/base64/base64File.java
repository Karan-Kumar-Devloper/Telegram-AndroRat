package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.util.Base64;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class base64File {

    public static String encodeFileToBase64(String filePath) {
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            byte[] buffer = new byte[fileInputStream.available()];
            fileInputStream.read(buffer);
            fileInputStream.close();
            return Base64.encodeToString(buffer, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void decodeBase64ToFile(String base64String, String outputPath) {
        try {
            byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
            FileOutputStream fileOutputStream = new FileOutputStream(outputPath);
            fileOutputStream.write(decodedBytes);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
