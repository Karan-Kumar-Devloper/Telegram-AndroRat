package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.util.Base64;

public class base64Text {

    public static String encode(String text) {
        byte[] data = text.getBytes();
        return Base64.encodeToString(data, Base64.DEFAULT);
    }

    public static String decode(String encodedText) {
        byte[] decodedData = Base64.decode(encodedText, Base64.DEFAULT);
        return new String(decodedData);
    }
}
