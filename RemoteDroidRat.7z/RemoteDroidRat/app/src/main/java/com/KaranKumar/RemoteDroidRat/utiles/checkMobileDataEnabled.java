package com.KaranKumar.RemoteDroidRat.utiles;


import android.widget.Toast;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class checkMobileDataEnabled {

    public static void performActionBasedOnMobileData(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                if (activeNetwork.isConnectedOrConnecting()) {
                    // Mobile data is on, perform your action here
                    showToast(context, "Mobile Data is ON. Performing action...");
                    // Perform your action here
                } else {
                    // Mobile data is off
                    showToast(context, "Mobile Data is OFF.");
                    // Perform alternative action or notify the user
                }
            } else {
                // No active mobile network
                showToast(context, "No active mobile network.");
            }
        }
    }

    private static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

}
