package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ImageUtil {

    public static void saveBitmapToFile(Bitmap bitmap, String outputPath) {
        try {
            File file = new File(outputPath);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
