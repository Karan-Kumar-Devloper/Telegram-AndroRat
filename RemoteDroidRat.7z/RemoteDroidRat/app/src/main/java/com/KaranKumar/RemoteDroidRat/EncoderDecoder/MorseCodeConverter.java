package com.KaranKumar.RemoteDroidRat.EncoderDecoder;

import java.util.Scanner;

public class MorseCodeConverter {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Would you like to convert English to Morse (yes or no)? ");
		String answer = input.nextLine();

		if (answer.equalsIgnoreCase("yes")) {
			System.out.println("Please enter the text you want to translate into Morse code: ");
			String english = input.nextLine();
			System.out.println(MorseEncode(english));
		}

		if (answer.equalsIgnoreCase("no")) {
			System.out.print("Morse to English? ");
			String answer2 = input.nextLine();
			if (answer2.equalsIgnoreCase("yes")) {
				System.out.println("Please enter the Morse code you want to translate into English: ");
				String code = input.nextLine();
				System.out.println(MorseDecode(code));
			}
		}
	}

   private static String encode(String toEncode) {
		String morse = toEncode;

		if (toEncode.equals("a"))
			morse = ".-";
		if (toEncode.equals("b"))
			morse = "-...";
		if (toEncode.equals("c"))
			morse = "-.-.";
		if (toEncode.equals("d"))
			morse = "-..";
		if (toEncode.equals("e"))
			morse = ".";
		if (toEncode.equals("f"))
			morse = "..-.";
		if (toEncode.equals("g"))
			morse = "--.";
		if (toEncode.equals("h"))
			morse = "....";
		if (toEncode.equals("i"))
			morse = "..";
		if (toEncode.equals("j"))
			morse = ".---";
		if (toEncode.equals("k"))
			morse = "-.-";
		if (toEncode.equals("l"))
			morse = ".-..";
		if (toEncode.equals("m"))
			morse = "--";
		if (toEncode.equals("n"))
			morse = "-.";
		if (toEncode.equals("o"))
			morse = "---";
		if (toEncode.equals("p"))
			morse = ".--.";
		if (toEncode.equals("q"))
			morse = "--.-";
		if (toEncode.equals("r"))
			morse = ".-.";
		if (toEncode.equals("s"))
			morse = "...";
		if (toEncode.equals("t"))
			morse = "-";
		if (toEncode.equals("u"))
			morse = "..-";
		if (toEncode.equals("v"))
			morse = "...-";
		if (toEncode.equals("w"))
			morse = ".--";
		if (toEncode.equals("x"))
			morse = "-..-";
		if (toEncode.equals("y"))
			morse = "-.--";
		if (toEncode.equals("z"))
			morse = "--..";
		if (toEncode.equals("0"))
			morse = "-----";
		if (toEncode.equals("1"))
			morse = ".----";
		if (toEncode.equals("2"))
			morse = "..---";
		if (toEncode.equals("3"))
			morse = "...--";
		if (toEncode.equals("4"))
			morse = "....-";
		if (toEncode.equals("5"))
			morse = ".....";
		if (toEncode.equals("6"))
			morse = "-....";
		if (toEncode.equals("7"))
			morse = "--...";
		if (toEncode.equals("8"))
			morse = "---..";
		if (toEncode.equals("9"))
			morse = "----.";
		if (toEncode.equals("."))
			morse = ".-.-";
		if (toEncode.equals(","))
			morse = "--..--";
		if (toEncode.equals("?"))
			morse = "..--..";
		if (toEncode.equals("="))
			morse = "..--.-..";
		if (toEncode.equals("@"))
			morse = ".-..-..";
		if (toEncode.equals("-"))
			morse ="·•.";
	   if (toEncode.equals(":"))
		   morse =".•·";
	   if (toEncode.equals("/"))
		   morse ="•.•";
		if (toEncode.equals("A"))
			morse = "--...-.";
		if (toEncode.equals("B"))
			morse = "-..--.";
		if (toEncode.equals("C"))
			morse = ".--.---";
		if (toEncode.equals("D"))
			morse = "-.--.-.";
		if (toEncode.equals("E"))
			morse = "--.·-.";
		if (toEncode.equals("F"))
			morse = ".-·--";
		if (toEncode.equals("G"))
			morse = ".--.–";
		if (toEncode.equals("H"))
			morse = "-.·-.";
		if (toEncode.equals("I"))
			morse = "..-..-.";
		if (toEncode.equals("J"))
			morse = "---...";
		if (toEncode.equals("K"))
			morse = "-..--.-.";
		if (toEncode.equals("L"))
			morse = ".-.-.-.";
		if (toEncode.equals("M"))
			morse = ".-_.-.-.";
		if (toEncode.equals("N"))
			morse = "·";
		if (toEncode.equals("O"))
			morse = ".----.";
		if (toEncode.equals("P"))
			morse = "-....-";
		if (toEncode.equals("Q"))
			morse = "-..-..-";
		if (toEncode.equals("R"))
			morse = "....-.";
		if (toEncode.equals("S"))
			morse = "·.";
		if (toEncode.equals("T"))
			morse = ".·";
		if (toEncode.equals("U"))
			morse = "–.";
		if (toEncode.equals("V"))
			morse = ".–";
		if (toEncode.equals("W"))
			morse = "-.·";
		if (toEncode.equals("X"))
			morse = "—·";
		if (toEncode.equals("Y"))
			morse = "·—";
		if (toEncode.equals("Z"))
			morse = "—";

		return morse;
	}

	private static String decode(String toEncode) {
		String morse = toEncode;

		if (toEncode.equals(".-"))
			morse = "a";
		if (toEncode.equals("-..."))
			morse = "b";
		if (toEncode.equals("-.-."))
			morse = "c";
		if (toEncode.equals("-.."))
			morse = "d";
		if (toEncode.equals("."))
			morse = "e";
		if (toEncode.equals("..-."))
			morse = "f";
		if (toEncode.equals("--."))
			morse = "g";
		if (toEncode.equals("...."))
			morse = "h";
		if (toEncode.equals(".."))
			morse = "i";
		if (toEncode.equals(".---"))
			morse = "j";
		if (toEncode.equals("-.-"))
			morse = "k";
		if (toEncode.equals(".-.."))
			morse = "l";
		if (toEncode.equals("--"))
			morse = "m";
		if (toEncode.equals("-."))
			morse = "n";
		if (toEncode.equals("---"))
			morse = "o";
		if (toEncode.equals(".--."))
			morse = "p";
		if (toEncode.equals("--.-"))
			morse = "q";
		if (toEncode.equals(".-."))
			morse = "r";
		if (toEncode.equals("..."))
			morse = "s";
		if (toEncode.equals("-"))
			morse = "t";
		if (toEncode.equals("..-"))
			morse = "u";
		if (toEncode.equals("...-"))
			morse = "v";
		if (toEncode.equals(".--"))
			morse = "w";
		if (toEncode.equals("-..-"))
			morse = "x";
		if (toEncode.equals("-.--"))
			morse = "y";
		if (toEncode.equals("--.."))
			morse = "z";
		if (toEncode.equals("-----"))
			morse = "0";
		if (toEncode.equals(".----"))
			morse = "1";
		if (toEncode.equals("..---"))
			morse = "2";
		if (toEncode.equals("...--"))
			morse = "3";
		if (toEncode.equals("....-"))
			morse = "4";
		if (toEncode.equals("....."))
			morse = "5";
		if (toEncode.equals("-...."))
			morse = "6";
		if (toEncode.equals("--..."))
			morse = "7";
		if (toEncode.equals("---.."))
			morse = "8";
		if (toEncode.equals("----."))
			morse = "9";
		if (toEncode.equals("--...-."))
			morse = "A";
		if (toEncode.equals("-..--."))
			morse = "B";
		if (toEncode.equals(".--.---"))
			morse = "C";
		if (toEncode.equals("-.--.-."))
			morse = "D";
		if (toEncode.equals("--.·-."))
			morse = "E";
		if (toEncode.equals(".-·--"))
			morse = "F";
		if (toEncode.equals(".--.–"))
			morse = "G";
		if (toEncode.equals("-.·-."))
			morse = "H";
		if (toEncode.equals("..-..-."))
			morse = "I";
		if (toEncode.equals("---..."))
			morse = "J";
		if (toEncode.equals("-..--.-."))
			morse = "K";
		if (toEncode.equals(".-_.-.-."))
			morse = "M";
		if (toEncode.equals(".-.-.-."))
			morse = "L";
		if (toEncode.equals("·"))
			morse = "N";
		if (toEncode.equals(".----."))
			morse = "O";
		if (toEncode.equals("-....-"))
			morse = "P";
		if (toEncode.equals("-..-..-"))
			morse = "Q";
		if (toEncode.equals("....-."))
			morse = "R";
		if (toEncode.equals("·."))
			morse = "S";
		if (toEncode.equals(".·"))
			morse = "T";
		if (toEncode.equals("–."))
			morse = "U";
		if (toEncode.equals(".–"))
			morse = "V";
		if (toEncode.equals("-.·"))
			morse = "W";
		if (toEncode.equals("—·"))
			morse = "X";
		if (toEncode.equals("·—"))
			morse = "Y";
		if (toEncode.equals("—"))
			morse = "Z";
		if (toEncode.equals("..--.-.."))
			morse = "=";
		if (toEncode.equals(".-..-.."))
			morse = "@";
		if (toEncode.equals("..--.."))
			morse = "?";
		if (toEncode.equals("--..--"))
			morse = ",";
		if (toEncode.equals(".-.-"))
			morse = ".";
			
		if (toEncode.equals("·•."))
			morse = "-";
		if (toEncode.equals(".•·"))
			morse = ":";
		if (toEncode.equals("•.•"))
			morse = "/";
		if (toEncode.equals("|"))
			morse = "";

		return morse;
	}

	public static String MorseEncode(String text) {
		String newText = "";
		String selectedChar;
		String convertedChar;
		for (int i = 0; i < text.length(); i++) {
			selectedChar = text.charAt(i) + "";
			convertedChar = encode(selectedChar);

			if (convertedChar.equals(" ")) {
				newText = newText + "| ";
			} else {
				newText = newText + convertedChar;
				if (!convertedChar.equals(" ")) {
					newText = newText + " ";
				}
			}
		}

		return newText;
	}

	public static String MorseDecode(String text) {
		String[] morseSymbols = text.split(" ");
		StringBuilder newMorse = new StringBuilder();

		for (String symbol : morseSymbols) {
			if (!symbol.isEmpty()) {
				String convertedMorse = decode(symbol);
				newMorse.append(convertedMorse);
			}
		}

		return newMorse.toString();
	}

}
