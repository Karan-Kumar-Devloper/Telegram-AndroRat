
package com.KaranKumar.RemoteDroidRat.EncoderDecoder;

import java.util.Scanner;

public class TextHexConverter {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Would you like to convert English to Hex (yes or no)? ");
		String answer = input.nextLine();

		if (answer.equalsIgnoreCase("yes")) {
			System.out.println("Please enter the text you want to translate into Hex code: ");
			String english = input.nextLine();
			System.out.println(textToHex(english));
		}

		if (answer.equalsIgnoreCase("no")) {
			System.out.print("Hex to English? ");
			String answer2 = input.nextLine();
			if (answer2.equalsIgnoreCase("yes")) {
				System.out.println("Please enter the Morse code you want to translate into English: ");
				String code = input.nextLine();
				System.out.println(hexToText(code));
			}
		}
	} 


    public static String textToHex(String text) {
        StringBuilder hexStringBuilder = new StringBuilder();

        for (char character : text.toCharArray()) {
            String hexValue = Integer.toHexString(character);
            hexStringBuilder.append(hexValue);
        }

        return hexStringBuilder.toString();
    }

    public static String hexToText(String hexString) {
        StringBuilder textStringBuilder = new StringBuilder();

        for (int i = 0; i < hexString.length(); i += 2) {
            String hexValue = hexString.substring(i, i + 2);
            char character = (char) Integer.parseInt(hexValue, 16);
            textStringBuilder.append(character);
        }

        return textStringBuilder.toString();
    }
}
