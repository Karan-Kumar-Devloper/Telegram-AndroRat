package com.KaranKumar.RemoteDroidRat.services;
import android.app.admin.DeviceAdminReceiver;

public class deviceAdminService extends DeviceAdminReceiver {
    // Implementation of callbacks goes here
}
