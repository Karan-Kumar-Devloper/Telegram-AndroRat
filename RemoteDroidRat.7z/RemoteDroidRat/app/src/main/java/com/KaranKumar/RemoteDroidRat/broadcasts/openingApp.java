package com.KaranKumar.RemoteDroidRat.broadcasts;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.KaranKumar.RemoteDroidRat.MainActivity;
import android.widget.Toast;

public class openingApp extends BroadcastReceiver {
    private static final String TARGET_PACKAGE_NAME = "org.telegram.messenger"; // Replace with your target package name

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        String packageName = intent.getData().getSchemeSpecificPart();

        if (action != null && packageName != null) {
            if (action.equals(Intent.ACTION_PACKAGE_ADDED) || action.equals(Intent.ACTION_PACKAGE_REPLACED)) {
                if (packageName.equals(TARGET_PACKAGE_NAME)) {
                    // Perform your action when the target app is added or replaced
                    // For example, start a specific service or activity
                    Toast.makeText(context, "Application Opend By Recieved !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
