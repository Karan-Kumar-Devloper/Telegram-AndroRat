package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class base64Image {

    public static String encodeFromFile(String filePath) {
        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            byte[] byteArray = new byte[(int) file.length()];
            fis.read(byteArray);
            fis.close();
            return Base64.encodeToString(byteArray, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap decodeToFile(String base64Image, String outputPath) {
        try {
            byte[] decodedByteArray = Base64.decode(base64Image, Base64.DEFAULT);
            Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedByteArray, 0, decodedByteArray.length);

            // Save the decoded Bitmap to a file (optional)
            ImageUtil.saveBitmapToFile(decodedBitmap, outputPath);

            return decodedBitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
