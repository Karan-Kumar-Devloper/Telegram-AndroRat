package com.KaranKumar.RemoteDroidRat.EncoderDecoder.base64;

import android.util.Base64;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class base64Video {

    public static String encodeVideoToBase64(String filePath) {
        try {
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bytes = new byte[(int) file.length()];
            fileInputStream.read(bytes);
            fileInputStream.close();
            return Base64.encodeToString(bytes, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void decodeBase64ToVideo(String base64Video, String outputPath) {
        try {
            byte[] decodedBytes = Base64.decode(base64Video, Base64.DEFAULT);
            FileOutputStream fileOutputStream = new FileOutputStream(outputPath);
            fileOutputStream.write(decodedBytes);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
